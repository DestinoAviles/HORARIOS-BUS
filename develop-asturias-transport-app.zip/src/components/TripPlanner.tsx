import React, { useState } from 'react';
import { PhysicalStop } from '../types/cta';
import { Compass, MapPin, ArrowRight, Clock, CreditCard, Bus, CheckCircle2 } from 'lucide-react';

interface TripPlannerProps {
  stops: PhysicalStop[];
  onSelectStop: (stopId: string) => void;
}

export const TripPlanner: React.FC<TripPlannerProps> = ({ stops, onSelectStop }) => {
  const [originId, setOriginId] = useState<string>(stops[0]?.id || "33044001"); // Oviedo
  const [destinationId, setDestinationId] = useState<string>(stops[3]?.id || "33024001"); // Gijón
  const [planned, setPlanned] = useState<boolean>(true);

  const originStop = stops.find(s => s.id === originId) || stops[0];
  const destStop = stops.find(s => s.id === destinationId) || stops[3];

  const handleSwap = () => {
    setOriginId(destinationId);
    setDestinationId(originId);
  };

  // Distance calculation heuristic
  const isSameMunicipality = originStop.municipality === destStop.municipality;
  const estimatedZones = isSameMunicipality ? 1 : 2;
  const estimatedDuration = isSameMunicipality ? 18 : 32;

  return (
    <div className="space-y-6">
      
      {/* Route Selector Card */}
      <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-5">
        <div className="flex items-center space-x-2 pb-2 border-b border-slate-700">
          <Compass className="w-5 h-5 text-sky-400" />
          <h2 className="font-extrabold text-slate-100 text-base uppercase tracking-wide">
            Planificador de Rutas e Itinerarios CTA
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          
          {/* Origin */}
          <div className="md:col-span-5 space-y-1.5">
            <label className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>Origen (Parada Física)</span>
            </label>
            <select
              value={originId}
              onChange={(e) => setOriginId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-4 py-3 text-sm font-semibold focus:ring-2 focus:ring-sky-500 outline-none"
            >
              {stops.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.municipality})
                </option>
              ))}
            </select>
          </div>

          {/* Swap Button */}
          <div className="md:col-span-2 flex items-center justify-center pt-2 md:pt-6">
            <button
              onClick={handleSwap}
              className="p-3 rounded-xl bg-slate-700 hover:bg-sky-600 text-slate-200 hover:text-white transition-all shadow border border-slate-600"
              title="Intercambiar Origen y Destino"
            >
              <ArrowRight className="w-5 h-5 rotate-90 md:rotate-0" />
            </button>
          </div>

          {/* Destination */}
          <div className="md:col-span-5 space-y-1.5">
            <label className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5" />
              <span>Destino (Parada Física)</span>
            </label>
            <select
              value={destinationId}
              onChange={(e) => setDestinationId(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-4 py-3 text-sm font-semibold focus:ring-2 focus:ring-emerald-500 outline-none"
            >
              {stops.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.municipality})
                </option>
              ))}
            </select>
          </div>

        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={() => setPlanned(true)}
            className="w-full sm:w-auto px-6 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-lg shadow-sky-600/30 transition-all flex items-center justify-center space-x-2"
          >
            <Bus className="w-4 h-4" />
            <span>Calcular Mejor Ruta</span>
          </button>
        </div>
      </div>

      {/* Planned Itinerary Results */}
      {planned && (
        <div className="space-y-4">
          
          {/* Summary Card */}
          <div className="bg-gradient-to-r from-slate-800 via-slate-900 to-sky-950 rounded-2xl p-6 border border-sky-800/50 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-sky-400">
                  Ruta Directa Recomendada CTA
                </span>
                <h3 className="text-xl font-black text-white">
                  {originStop.municipality} → {destStop.municipality}
                </h3>
              </div>

              <div className="flex items-center space-x-3">
                <div className="bg-slate-900/90 px-3.5 py-2 rounded-xl border border-slate-700 text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Duración</div>
                  <div className="text-sm font-extrabold text-sky-400 flex items-center space-x-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>~{estimatedDuration} min</span>
                  </div>
                </div>

                <div className="bg-slate-900/90 px-3.5 py-2 rounded-xl border border-slate-700 text-center">
                  <div className="text-[10px] text-slate-400 uppercase font-bold">Zonas CTA</div>
                  <div className="text-sm font-extrabold text-emerald-400 flex items-center space-x-1">
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>{estimatedZones} {estimatedZones === 1 ? 'Zona' : 'Zonas'}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-300">
              <span className="flex items-center space-x-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Cubierto al 100% por la Tarjeta CTA CONECTA (0€ tarifa plana)</span>
              </span>
            </div>
          </div>

          {/* Step by Step Timeline */}
          <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-6">
            <h4 className="font-extrabold text-slate-100 text-sm uppercase tracking-wide">
              Pasos del Viaje
            </h4>

            <div className="space-y-6 relative before:absolute before:inset-0 before:left-4 before:w-0.5 before:bg-sky-500/40">
              
              {/* Step 1: Origin */}
              <div className="relative pl-10 space-y-1">
                <div className="absolute left-2.5 top-1 -translate-x-1/2 w-4 h-4 rounded-full bg-sky-500 border-2 border-white shadow" />
                <div className="font-extrabold text-sm text-slate-100">
                  Embarque en {originStop.name}
                </div>
                <p className="text-xs text-slate-400">
                  Acude a la marquesina/dársena. Código de Parada: <span className="font-mono text-sky-300">{originStop.id}</span>.
                </p>
                <button
                  onClick={() => onSelectStop(originStop.id)}
                  className="mt-1 text-xs text-sky-400 hover:underline font-semibold flex items-center space-x-1"
                >
                  <span>Ver salidas en tiempo real de esta parada</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              {/* Step 2: In transit */}
              <div className="relative pl-10 space-y-1">
                <div className="absolute left-2.5 top-1 -translate-x-1/2 w-3 h-3 rounded-full bg-slate-600 border border-slate-400" />
                <div className="font-bold text-xs text-sky-300">
                  Trayecto en Autobús Directo ({estimatedDuration} minutos)
                </div>
                <p className="text-xs text-slate-400">
                  Pasa tu tarjeta CTA CONECTA o billete de {estimatedZones} {estimatedZones === 1 ? 'zona' : 'zonas'} al subir.
                </p>
              </div>

              {/* Step 3: Destination */}
              <div className="relative pl-10 space-y-1">
                <div className="absolute left-2.5 top-1 -translate-x-1/2 w-4 h-4 rounded-full bg-emerald-500 border-2 border-white shadow" />
                <div className="font-extrabold text-sm text-slate-100">
                  Llegada a {destStop.name}
                </div>
                <p className="text-xs text-slate-400">
                  Llegada a {destStop.municipality}. Código de Parada: <span className="font-mono text-emerald-300">{destStop.id}</span>.
                </p>
                <button
                  onClick={() => onSelectStop(destStop.id)}
                  className="mt-1 text-xs text-emerald-400 hover:underline font-semibold flex items-center space-x-1"
                >
                  <span>Ver horarios de retorno</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
};
