import React from 'react';
import { Bus, ExternalLink, ShieldAlert, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="mt-12 bg-slate-950 border-t border-slate-800 text-slate-400 text-xs py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-6 border-b border-slate-800/80">
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2 text-slate-200 font-extrabold text-base">
              <Bus className="w-5 h-5 text-sky-400" />
              <span>Consorcio de Transportes de Asturias (CTA)</span>
            </div>
            <p className="max-w-xl text-slate-400">
              Aplicación web e integrador de la OpenAPI de CTA Asturias. Consulta de tiempos de paso en tiempo real, paradas físicas (<span className="font-mono text-sky-300">StopsFis</span>), itinerarios y generador de widgets para páginas web.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="https://openapi.consorcioasturias.com/api/"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-sky-300 font-semibold transition-colors flex items-center space-x-1.5"
            >
              <span>Swagger CTA OpenAPI</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <a
              href="https://www.ctaconecta.com"
              target="_blank"
              rel="noreferrer"
              className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-emerald-300 font-semibold transition-colors flex items-center space-x-1.5"
            >
              <span>ctaconecta.com</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-500 text-[11px]">
          <div className="flex items-center space-x-1">
            <ShieldAlert className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <span>
              Los datos en tiempo real provienen de la especificación OpenAPI de Consorcio de Transportes de Asturias.
            </span>
          </div>

          <div className="flex items-center space-x-1 text-slate-400">
            <span>Desarrollado con</span>
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500 inline" />
            <span>para publicar en webs y apps de Asturias &bull; {new Date().getFullYear()}</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
