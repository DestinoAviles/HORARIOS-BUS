import React from 'react';
import {
  Bus,
  MapPin,
  Route,
  Code2,
  Share2,
  CreditCard,
  Compass,
  Bookmark,
  Wifi,
  Activity,
  Sun,
  Moon
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  favoritesCount: number;
  openFavoritesModal: () => void;
  useLiveApi: boolean;
  setUseLiveApi: (live: boolean) => void;
  isLiveConnected: boolean;
  lastResponseMs?: number;
  appTheme?: 'dark' | 'light';
  setAppTheme?: (theme: 'dark' | 'light') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  favoritesCount,
  openFavoritesModal,
  useLiveApi,
  setUseLiveApi,
  isLiveConnected,
  lastResponseMs,
  appTheme = 'dark',
  setAppTheme
}) => {
  const isLight = appTheme === 'light';

  const navItems = [
    { id: 'board', label: 'Tiempos en Tiempo Real', icon: Bus, tag: 'Live' },
    { id: 'map', label: 'Mapa de Paradas', icon: MapPin },
    { id: 'lines', label: 'Líneas y Rutas', icon: Route },
    { id: 'planner', label: 'Planificador', icon: Compass },
    { id: 'fares', label: 'Tarifas CTA', icon: CreditCard },
    { id: 'widget', label: 'Publicar en mi Web (Opción B)', icon: Share2, highlight: true },
    { id: 'api', label: 'Documentación API', icon: Code2 }
  ];

  return (
    <header className={`sticky top-0 z-50 backdrop-blur-md border-b shadow-xl transition-colors ${
      isLight ? 'bg-white/95 border-slate-200 text-slate-900' : 'bg-slate-900/95 border-slate-800 text-slate-100'
    }`}>
      {/* Top Banner with CTA Branding & Status */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('board')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 via-sky-500 to-cyan-400 p-0.5 shadow-lg shadow-sky-500/20">
              <div className={`w-full h-full rounded-[10px] flex items-center justify-center ${isLight ? 'bg-white' : 'bg-slate-950'}`}>
                <Bus className="w-5 h-5 text-sky-600" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className={`font-extrabold text-lg tracking-tight ${
                  isLight ? 'text-slate-950' : 'bg-gradient-to-r from-sky-400 via-cyan-300 to-white bg-clip-text text-transparent'
                }`}>
                  CTA Asturias
                </span>
                <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded border tracking-wider ${
                  isLight ? 'bg-sky-100 text-sky-900 border-sky-300' : 'bg-sky-950 text-sky-300 border-sky-800/60'
                }`}>
                  OpenAPI 2.0
                </span>
              </div>
              <p className={`text-xs hidden sm:block ${isLight ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>
                Consorcio de Transportes de Asturias &bull; Paradas e Itinerarios
              </p>
            </div>
          </div>

          {/* Right Controls: Theme Switcher, Favorites & Live API Status */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            
            {/* High Contrast Light / Dark Mode Toggle */}
            {setAppTheme && (
              <button
                onClick={() => setAppTheme(isLight ? 'dark' : 'light')}
                className={`p-2 rounded-xl border font-bold text-xs flex items-center space-x-1.5 transition-all shadow-xs ${
                  isLight
                    ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border-amber-300'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                }`}
                title="Cambiar tema visual (Opción B: Fondo Blanco y Letras Negras)"
              >
                {isLight ? (
                  <>
                    <Moon className="w-4 h-4 text-slate-900" />
                    <span className="hidden lg:inline text-slate-900 font-extrabold">Modo Oscuro</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-4 h-4 text-amber-400" />
                    <span className="hidden lg:inline text-amber-300 font-bold">Fondo Blanco (Opción B)</span>
                  </>
                )}
              </button>
            )}

            {/* Live API / Mock Switch */}
            <div className={`hidden md:flex items-center p-1 rounded-lg border text-xs ${
              isLight ? 'bg-slate-100 border-slate-300' : 'bg-slate-800/80 border-slate-700/60'
            }`}>
              <button
                onClick={() => setUseLiveApi(true)}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-md transition-all ${
                  useLiveApi
                    ? 'bg-sky-600 text-white font-bold shadow-sm'
                    : isLight ? 'text-slate-700 hover:text-slate-900' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Intenta conectar directamente a https://openapi.consorcioasturias.com/api/"
              >
                <span className={`w-2 h-2 rounded-full ${isLiveConnected ? 'bg-emerald-400 animate-live-dot' : 'bg-amber-400'}`} />
                <span>API Real</span>
              </button>
              <button
                onClick={() => setUseLiveApi(false)}
                className={`flex items-center space-x-1.5 px-2.5 py-1 rounded-md transition-all ${
                  !useLiveApi
                    ? (isLight ? 'bg-slate-200 text-slate-950 font-bold' : 'bg-slate-700 text-slate-100 font-medium')
                    : isLight ? 'text-slate-700 hover:text-slate-900' : 'text-slate-400 hover:text-slate-200'
                }`}
                title="Modo Simulación Integrado en Tiempo Real"
              >
                <Activity className="w-3 h-3 text-cyan-600" />
                <span>Simulador</span>
              </button>
            </div>

            {/* Connection badge */}
            <div className={`hidden lg:flex items-center space-x-1.5 text-xs px-2.5 py-1 rounded-full border ${
              isLight ? 'bg-slate-100 border-slate-300 text-slate-700' : 'bg-slate-800/60 border-slate-700/50 text-slate-300'
            }`}>
              <Wifi className={`w-3.5 h-3.5 ${useLiveApi && isLiveConnected ? 'text-emerald-500' : 'text-cyan-500'}`} />
              <span className="font-mono text-[11px] font-bold">
                {lastResponseMs ? `${lastResponseMs}ms` : '30s refresh'}
              </span>
            </div>

            {/* Favorites Drawer Toggle */}
            <button
              onClick={openFavoritesModal}
              className={`relative p-2 rounded-xl border transition-colors flex items-center space-x-2 ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-900'
                  : 'bg-slate-800/90 hover:bg-slate-700 border-slate-700 text-slate-200'
              }`}
              title="Mis paradas guardadas"
            >
              <Bookmark className="w-4 h-4 text-amber-500 fill-amber-500/20" />
              <span className="text-xs font-bold hidden sm:inline">Favoritos</span>
              {favoritesCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow">
                  {favoritesCount}
                </span>
              )}
            </button>
          </div>

        </div>

        {/* Navigation Tabs */}
        <div className={`flex space-x-1 overflow-x-auto no-scrollbar py-2 border-t text-xs sm:text-sm ${
          isLight ? 'border-slate-200' : 'border-slate-800/80'
        }`}>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg font-bold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-md shadow-sky-600/25'
                    : item.highlight
                    ? (isLight ? 'bg-emerald-100 text-emerald-950 border border-emerald-300 hover:bg-emerald-200' : 'bg-emerald-950/60 text-emerald-300 border border-emerald-700/50 hover:bg-emerald-900/60')
                    : (isLight ? 'text-slate-700 hover:text-slate-950 hover:bg-slate-100' : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60')
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-emerald-600' : (isLight ? 'text-slate-600' : 'text-slate-400')}`} />
                <span>{item.label}</span>
                {item.tag && (
                  <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded ${
                    isLight ? 'bg-sky-100 text-sky-900 border border-sky-300' : 'bg-sky-400/20 text-sky-200'
                  }`}>
                    {item.tag}
                  </span>
                )}
              </button>
            );
          })}
        </div>

      </div>
    </header>
  );
};
