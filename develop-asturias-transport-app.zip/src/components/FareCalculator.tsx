import React, { useState } from 'react';
import { CTA_FARES_TABLE } from '../data/asturiasTransitData';
import { CreditCard, ShieldCheck, Sparkles } from 'lucide-react';

export const FareCalculator: React.FC = () => {
  const [tripsPerMonth, setTripsPerMonth] = useState<number>(30);
  const [selectedZones, setSelectedZones] = useState<number>(2);

  const fareRow = CTA_FARES_TABLE.find(f => f.zones === selectedZones) || CTA_FARES_TABLE[1];

  const singleCostMonth = tripsPerMonth * fareRow.singleTicket;
  const monederoCostMonth = tripsPerMonth * fareRow.ctaMonedero;

  const monederoSavings = singleCostMonth - monederoCostMonth;
  const conectaSavings = singleCostMonth;

  return (
    <div className="space-y-6">
      
      {/* Banner Tarjeta CONECTA */}
      <div className="bg-gradient-to-r from-sky-900 via-blue-900 to-cyan-950 rounded-2xl p-6 border border-sky-700/80 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-10 -bottom-10 w-60 h-60 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-0.5 rounded bg-emerald-500 text-slate-950 text-xs font-black uppercase tracking-wider">
                Tarifa Plana Asturias
              </span>
              <span className="text-xs text-sky-200 font-medium">Consorcio de Transportes de Asturias</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Tarjeta CTA CONECTA
            </h2>
            <p className="text-sm text-slate-300 max-w-xl">
              Viaja de forma ilimitada por todos los autobuses urbanos e interurbanos de Asturias (ALSA, TUA, EMTUSA) con una tarifa plana máxima mensual.
            </p>
          </div>

          <div className="shrink-0 bg-slate-950/80 p-4 rounded-xl border border-sky-500/40 text-center shadow-lg">
            <div className="text-xs text-slate-400 font-bold uppercase">Toque máximo mensual</div>
            <div className="text-3xl font-black text-emerald-400">30,00 €</div>
            <div className="text-[11px] text-slate-400 font-medium">Viajes ilimitados tras alcanzar el tope</div>
          </div>
        </div>
      </div>

      {/* Calculator Form */}
      <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-6">
        <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
          <CreditCard className="w-5 h-5 text-sky-400" />
          <h3 className="font-extrabold text-slate-100 text-base uppercase tracking-wide">
            Calculadora de Ahorro en Transportes
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Number of Zones Slider */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold uppercase text-slate-300">
                Número de Zonas CTA del Trayecto:
              </label>
              <span className="px-3 py-1 rounded-lg bg-sky-950 border border-sky-700 text-sky-300 font-bold text-sm">
                {selectedZones} {selectedZones === 1 ? 'Zona' : 'Zonas'}
              </span>
            </div>
            <input
              type="range"
              min="1"
              max="6"
              value={selectedZones}
              onChange={(e) => setSelectedZones(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer h-2 bg-slate-900 rounded-lg"
            />
            <p className="text-xs text-slate-400 italic">
              {fareRow.desc}
            </p>
          </div>

          {/* Trips per Month Slider */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold uppercase text-slate-300">
                Viajes Estimados al Mes:
              </label>
              <span className="px-3 py-1 rounded-lg bg-emerald-950 border border-emerald-700 text-emerald-300 font-bold text-sm">
                {tripsPerMonth} viajes / mes
              </span>
            </div>
            <input
              type="range"
              min="2"
              max="100"
              step="2"
              value={tripsPerMonth}
              onChange={(e) => setTripsPerMonth(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer h-2 bg-slate-900 rounded-lg"
            />
            <p className="text-xs text-slate-400 italic">
              Ej: Ir y volver del trabajo/estudios 20 días al mes = 40 viajes
            </p>
          </div>

        </div>

        {/* Comparison Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t border-slate-700">
          
          {/* Single Ticket */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-700/80 space-y-2">
            <div className="text-xs font-bold text-slate-400 uppercase">Billete Sencillo</div>
            <div className="text-2xl font-extrabold text-slate-200">
              {fareRow.singleTicket.toFixed(2)} € <span className="text-xs font-normal text-slate-500">/viaje</span>
            </div>
            <div className="pt-2 text-xs text-slate-400 border-t border-slate-800">
              Gasto mensual sin tarjeta: <span className="font-bold text-slate-200">{singleCostMonth.toFixed(2)} €</span>
            </div>
          </div>

          {/* CTA Monedero */}
          <div className="bg-slate-900 p-5 rounded-2xl border border-sky-800/80 space-y-2">
            <div className="text-xs font-bold text-sky-400 uppercase flex items-center justify-between">
              <span>CTA Monedero</span>
              <span className="text-[10px] bg-sky-950 px-1.5 py-0.5 rounded text-sky-300">Descuento</span>
            </div>
            <div className="text-2xl font-extrabold text-sky-300">
              {fareRow.ctaMonedero.toFixed(2)} € <span className="text-xs font-normal text-slate-500">/viaje</span>
            </div>
            <div className="pt-2 text-xs text-slate-400 border-t border-slate-800">
              Gasto mensual: <span className="font-bold text-sky-300">{monederoCostMonth.toFixed(2)} €</span>
              <div className="text-[11px] text-emerald-400 font-semibold mt-1">
                Ahorras {monederoSavings.toFixed(2)} € al mes
              </div>
            </div>
          </div>

          {/* CTA CONECTA */}
          <div className="bg-gradient-to-br from-emerald-950 via-slate-900 to-slate-900 p-5 rounded-2xl border border-emerald-500/60 space-y-2 shadow-lg relative">
            <div className="text-xs font-bold text-emerald-400 uppercase flex items-center justify-between">
              <span>CTA CONECTA</span>
              <Sparkles className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-black text-emerald-300">
              0,00 € <span className="text-xs font-normal text-emerald-400/80">/por viaje adicional</span>
            </div>
            <div className="pt-2 text-xs text-slate-300 border-t border-emerald-900/60">
              Gasto máximo fijado en <span className="font-extrabold text-emerald-300">30,00 €/mes</span>
              <div className="text-[11px] text-emerald-400 font-extrabold mt-1">
                Ahorras {Math.max(0, conectaSavings - 30).toFixed(2)} € al mes
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Official CTA Tariff Table */}
      <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-4">
        <h3 className="font-extrabold text-slate-100 text-sm uppercase tracking-wide flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-sky-400" />
          <span>Tabla Tarifaria Oficial Consorcio de Transportes de Asturias</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-200">
            <thead className="bg-slate-900 text-slate-400 uppercase font-mono border-b border-slate-700">
              <tr>
                <th className="p-3">Número de Zonas</th>
                <th className="p-3">Billete Sencillo</th>
                <th className="p-3">CTA Monedero</th>
                <th className="p-3">Tarjeta CONECTA</th>
                <th className="p-3">Descripción / Ejemplos</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-700/60">
              {CTA_FARES_TABLE.map((row) => (
                <tr
                  key={row.zones}
                  className={`hover:bg-slate-700/40 transition-colors ${
                    row.zones === selectedZones ? 'bg-sky-950/50 font-bold' : ''
                  }`}
                >
                  <td className="p-3 font-mono font-bold text-sky-400">
                    {row.zones} {row.zones === 1 ? 'Zona' : 'Zonas'}
                  </td>
                  <td className="p-3 font-mono">{row.singleTicket.toFixed(2)} €</td>
                  <td className="p-3 font-mono text-sky-300">{row.ctaMonedero.toFixed(2)} €</td>
                  <td className="p-3 font-mono text-emerald-400 font-bold">0,00 € (Toque 30€)</td>
                  <td className="p-3 text-slate-400">{row.desc}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
