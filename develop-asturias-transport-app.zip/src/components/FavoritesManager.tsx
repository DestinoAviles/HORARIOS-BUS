import React from 'react';
import { PhysicalStop } from '../types/cta';
import { X, Bookmark, Trash2, Bus } from 'lucide-react';

interface FavoritesManagerProps {
  isOpen: boolean;
  onClose: () => void;
  favorites: string[];
  stops: PhysicalStop[];
  onSelectStop: (stopId: string) => void;
  toggleFavorite: (stopId: string) => void;
}

export const FavoritesManager: React.FC<FavoritesManagerProps> = ({
  isOpen,
  onClose,
  favorites,
  stops,
  onSelectStop,
  toggleFavorite
}) => {
  if (!isOpen) return null;

  const favoriteStops = stops.filter(s => favorites.includes(s.id));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        
        {/* Header */}
        <div className="p-4 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bookmark className="w-5 h-5 text-amber-400 fill-amber-400/20" />
            <h2 className="font-extrabold text-slate-100 text-sm uppercase tracking-wide">
              Paradas Favoritas Guardadas ({favoriteStops.length})
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 max-h-[420px] overflow-y-auto space-y-2">
          {favoriteStops.length === 0 ? (
            <div className="py-10 text-center space-y-2">
              <Bookmark className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm font-semibold text-slate-300">
                No tienes paradas guardadas aún
              </p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Haz clic en el icono del marcador de cualquier parada para añadirla a tu lista de acceso rápido.
              </p>
            </div>
          ) : (
            favoriteStops.map(stop => (
              <div
                key={stop.id}
                className="p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 flex items-center justify-between gap-3 group transition-colors"
              >
                <div
                  className="flex-1 cursor-pointer space-y-1"
                  onClick={() => {
                    onSelectStop(stop.id);
                    onClose();
                  }}
                >
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-800">
                      {stop.id}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {stop.municipality} ({stop.zone})
                    </span>
                  </div>

                  <div className="font-bold text-sm text-slate-100 group-hover:text-sky-300 transition-colors">
                    {stop.name}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => {
                      onSelectStop(stop.id);
                      onClose();
                    }}
                    className="p-2 rounded-lg bg-sky-600 hover:bg-sky-500 text-white transition-colors"
                    title="Ver salidas"
                  >
                    <Bus className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => toggleFavorite(stop.id)}
                    className="p-2 rounded-lg bg-slate-900 hover:bg-rose-950 text-slate-400 hover:text-rose-400 border border-slate-700 transition-colors"
                    title="Eliminar de favoritos"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-800/50 border-t border-slate-700/80 text-center text-xs text-slate-400">
          Guardados localmente en tu navegador
        </div>

      </div>
    </div>
  );
};
