import React, { useState } from 'react';
import { PhysicalStop, WidgetConfig } from '../types/cta';
import { generateMockItineraries } from '../data/asturiasTransitData';
import { Copy, Check, Eye, Code, Sparkles, Sliders, Bus, Clock, Sun } from 'lucide-react';

interface WebWidgetBuilderProps {
  stops: PhysicalStop[];
  initialStopId?: string;
  initialMinutes?: number;
}

export const WebWidgetBuilder: React.FC<WebWidgetBuilderProps> = ({
  stops,
  initialStopId = "33044001",
  initialMinutes = 30
}) => {
  const [config, setConfig] = useState<WidgetConfig>({
    stopId: initialStopId,
    minutes: initialMinutes,
    theme: 'light', // Default to high-clarity Light theme as requested
    mode: 'board',
    showHeader: true,
    showOperator: true,
    showPlatform: true,
    autoRefresh: 30,
    customTitle: 'Próximas Salidas CTA en Tiempo Real',
    width: '100%',
    height: '420px'
  });

  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [codeType, setCodeType] = useState<'iframe' | 'script' | 'react'>('iframe');

  const currentStop = stops.find(s => s.id === config.stopId) || stops[0];
  const sampleItineraries = generateMockItineraries(config.stopId, config.minutes).slice(0, 4);

  // Theme styles for live preview with enhanced light contrast mode
  const themeClasses: Record<WidgetConfig['theme'], string> = {
    light: 'border-slate-300 bg-white text-slate-900 shadow-xl',
    sky: 'border-sky-500/50 bg-slate-900 text-sky-300',
    emerald: 'border-emerald-500/50 bg-slate-900 text-emerald-300',
    violet: 'border-purple-500/50 bg-slate-900 text-purple-300',
    amber: 'border-amber-500/50 bg-slate-900 text-amber-300',
    slate: 'border-slate-700 bg-slate-900 text-slate-200'
  };

  const headerColors: Record<WidgetConfig['theme'], string> = {
    light: 'bg-slate-100 border-b border-slate-200 text-slate-950',
    sky: 'bg-gradient-to-r from-sky-900 to-blue-900 text-sky-100',
    emerald: 'bg-gradient-to-r from-emerald-900 to-teal-900 text-emerald-100',
    violet: 'bg-gradient-to-r from-purple-900 to-indigo-900 text-purple-100',
    amber: 'bg-gradient-to-r from-amber-950 to-orange-950 text-amber-100',
    slate: 'bg-slate-800 text-slate-100'
  };

  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://mimi-asturias-bus.vercel.app';

  // Embed Codes
  const iframeCode = `<iframe 
  src="${currentOrigin}/?widget=true&stopId=${config.stopId}&minutos=${config.minutes}&theme=${config.theme}&mode=${config.mode}" 
  width="${config.width}" 
  height="${config.height}" 
  style="border: 1px solid ${config.theme === 'light' ? '#cbd5e1' : '#334155'}; border-radius: 12px; overflow: hidden;"
  title="CTA Asturias - Panel de Parada ${config.stopId}"
  loading="lazy">
</iframe>`;

  const jsScriptCode = `<div id="cta-bus-widget-${config.stopId}"></div>
<script 
  src="${currentOrigin}/cta-widget.js" 
  data-stop-id="${config.stopId}" 
  data-minutes="${config.minutes}" 
  data-theme="${config.theme}" 
  data-mode="${config.mode}"
  async>
</script>`;

  const reactComponentCode = `import React from 'react';

export const CtaBusStopWidget = () => {
  const url = "${currentOrigin}/?widget=true&stopId=${config.stopId}&minutos=${config.minutes}&theme=${config.theme}";
  return (
    <iframe 
      src={url}
      style={{ width: '${config.width}', height: '${config.height}', border: '1px solid ${config.theme === 'light' ? '#cbd5e1' : '#334155'}', borderRadius: '12px' }}
      title="CTA Asturias Arrival Board"
    />
  );
};`;

  const handleCopyCode = (code: string, type: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(type);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-sky-950 rounded-2xl p-6 border border-emerald-700/60 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <span className="px-2.5 py-0.5 rounded bg-emerald-500 text-slate-950 text-xs font-black uppercase">
                Widget Integrable
              </span>
              <span className="text-xs text-emerald-300 font-medium">Publica en tu Sitio Web / Blog</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Generador de Widgets para Publicar en tu Web
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
              Personaliza el panel de tiempos en tiempo real de cualquier parada física del Consorcio de Transportes de Asturias (<span className="font-mono text-sky-300">/api/StopsFis/{config.stopId}/{config.minutes}/itineraries</span>) e insértalo fácilmente en tu portal.
            </p>
          </div>

          <div className="bg-slate-950/80 p-3 rounded-xl border border-emerald-500/40 text-center shrink-0">
            <Sparkles className="w-6 h-6 text-emerald-400 mx-auto mb-1" />
            <div className="text-xs font-bold text-emerald-300">Alta Legibilidad & Tipografía Clara</div>
            <div className="text-[10px] text-slate-400">Opción de Fondo Blanco y Texto Negro</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Controls Column (Customizer) */}
        <div className="lg:col-span-5 bg-slate-800/90 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-5">
          <div className="flex items-center space-x-2 pb-3 border-b border-slate-700">
            <Sliders className="w-5 h-5 text-sky-400" />
            <h2 className="font-extrabold text-slate-100 text-sm uppercase tracking-wide">
              Configurador del Widget
            </h2>
          </div>

          {/* Stop selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-sky-400 uppercase">
              Parada Física de Asturias (StopsFis ID)
            </label>
            <select
              value={config.stopId}
              onChange={(e) => setConfig({ ...config, stopId: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 text-slate-100 rounded-xl px-3 py-2.5 text-xs font-semibold focus:ring-2 focus:ring-sky-500"
            >
              {stops.map(s => (
                <option key={s.id} value={s.id}>
                  [{s.id}] {s.name} ({s.municipality})
                </option>
              ))}
            </select>
          </div>

          {/* Custom title */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase">
              Título Personalizado
            </label>
            <input
              type="text"
              value={config.customTitle}
              onChange={(e) => setConfig({ ...config, customTitle: e.target.value })}
              className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-sky-500"
            />
          </div>

          {/* Time window & Theme */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 uppercase">
                Ventana Tiempo
              </label>
              <select
                value={config.minutes}
                onChange={(e) => setConfig({ ...config, minutes: Number(e.target.value) })}
                className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-xl px-3 py-2 text-xs"
              >
                {[15, 30, 60, 120].map(m => (
                  <option key={m} value={m}>{m} minutos</option>
                ))}
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-sky-400 uppercase flex items-center space-x-1">
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>Estilo / Tipografía</span>
              </label>
              <select
                value={config.theme}
                onChange={(e) => setConfig({ ...config, theme: e.target.value as any })}
                className="w-full bg-slate-900 border border-slate-700 text-slate-100 font-medium rounded-xl px-3 py-2 text-xs focus:ring-2 focus:ring-sky-500"
              >
                <option value="light">⚪ Fondo Blanco & Letras Negras (Opción B - Tipografía Clara)</option>
                <option value="sky">🔵 Océano Sky (Fondo Oscuro Azul)</option>
                <option value="emerald">🟢 Verde Asturias (Fondo Oscuro Verde)</option>
                <option value="violet">🟣 Violeta Neón (Fondo Oscuro Violeta)</option>
                <option value="amber">🟠 Ámbar Noche (Fondo Oscuro Naranja)</option>
                <option value="slate">⚫ Gris Oscuro Pizarra</option>
              </select>
            </div>
          </div>

          {/* Layout Mode */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-300 uppercase">
              Diseño / Formato
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'board', label: 'Tabla Board' },
                { id: 'compact', label: 'Compacto' },
                { id: 'kiosk', label: 'Totem Kiosk' }
              ].map(m => (
                <button
                  key={m.id}
                  onClick={() => setConfig({ ...config, mode: m.id as any })}
                  className={`py-2 rounded-xl text-xs font-bold border transition-all ${
                    config.mode === m.id
                      ? 'bg-sky-600 text-white border-sky-400'
                      : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>

          {/* Toggles */}
          <div className="space-y-2 pt-2 border-t border-slate-700/80 text-xs text-slate-300">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={config.showHeader}
                onChange={(e) => setConfig({ ...config, showHeader: e.target.checked })}
                className="rounded accent-sky-500"
              />
              <span>Mostrar Encabezado con Nombre de Parada</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={config.showOperator}
                onChange={(e) => setConfig({ ...config, showOperator: e.target.checked })}
                className="rounded accent-sky-500"
              />
              <span>Mostrar Nombre de Compañía (ALSA, TUA, etc)</span>
            </label>
          </div>

        </div>

        {/* Right Preview & Code Export Column */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Live Preview Container */}
          <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-700">
              <div className="flex items-center space-x-2">
                <Eye className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-slate-100 text-xs uppercase tracking-wide">
                  Vista Previa en Tiempo Real del Widget ({config.theme === 'light' ? 'Opción B: Fondo Blanco + Texto Negro' : 'Fondo Oscuro'})
                </h3>
              </div>
              <span className="text-[11px] text-emerald-400 font-mono font-bold flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>En vivo</span>
              </span>
            </div>

            {/* Simulated Live Widget Canvas */}
            <div className={`rounded-xl border overflow-hidden ${themeClasses[config.theme]}`}>
              
              {/* Widget Header */}
              {config.showHeader && (
                <div className={`p-4 ${headerColors[config.theme]} flex items-center justify-between`}>
                  <div>
                    <div className={`text-[11px] uppercase font-bold tracking-wider ${config.theme === 'light' ? 'text-sky-700 font-mono' : 'opacity-80'}`}>
                      [{currentStop.id}] {currentStop.municipality} &bull; CTA ASTURIAS
                    </div>
                    <div className={`font-extrabold text-base sm:text-lg leading-tight ${config.theme === 'light' ? 'text-slate-950 tracking-tight' : ''}`}>
                      {config.customTitle || currentStop.name}
                    </div>
                  </div>
                  <Bus className={`w-6 h-6 ${config.theme === 'light' ? 'text-sky-700' : 'opacity-90'} shrink-0`} />
                </div>
              )}

              {/* Widget Body with Ultra Clear Light Mode Typography when theme === 'light' */}
              <div className={`p-4 space-y-3 ${
                config.theme === 'light'
                  ? 'bg-white divide-y divide-slate-200'
                  : 'bg-slate-950/90 divide-y divide-slate-800/80'
              }`}>
                {sampleItineraries.map((it) => (
                  <div key={it.id} className="pt-3 first:pt-0 flex items-center justify-between">
                    
                    {/* Left Column: Badge & Route Details */}
                    <div className="flex items-center space-x-3">
                      <span className={`px-2.5 py-1.5 rounded-lg font-black text-xs sm:text-sm shadow-sm ${
                        config.theme === 'light'
                          ? 'bg-sky-600 text-white border border-sky-700'
                          : 'bg-sky-600 text-white'
                      }`}>
                        {it.lineCode}
                      </span>
                      
                      <div>
                        <div className={`font-black text-sm sm:text-base ${
                          config.theme === 'light' ? 'text-slate-950 tracking-tight' : 'text-slate-100'
                        }`}>
                          {it.destination}
                        </div>
                        {config.showOperator && (
                          <div className={`text-xs font-semibold ${
                            config.theme === 'light' ? 'text-slate-600' : 'text-slate-400'
                          }`}>
                            {it.operator} {it.platform ? `• ${it.platform}` : ''}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right Column: Time & Countdown */}
                    <div className="flex items-center space-x-3">
                      <span className={`text-xs font-mono font-bold ${
                        config.theme === 'light' ? 'text-slate-600' : 'text-slate-400'
                      }`}>
                        {it.scheduledTime}
                      </span>
                      
                      <div className={`px-3 py-1.5 rounded-xl font-extrabold text-sm ${
                        config.theme === 'light'
                          ? 'bg-sky-100 border border-sky-300 text-sky-950 shadow-xs'
                          : 'bg-sky-950 border border-sky-500/50 text-sky-300'
                      }`}>
                        {it.estimatedMinutes} min
                      </div>
                    </div>

                  </div>
                ))}
              </div>

              {/* Widget Footer */}
              <div className={`p-2.5 border-t text-xs font-medium flex items-center justify-between px-4 ${
                config.theme === 'light'
                  ? 'bg-slate-100 border-slate-200 text-slate-700'
                  : 'bg-slate-900 border-slate-800 text-slate-400'
              }`}>
                <span className="font-semibold">Consorcio de Transportes de Asturias (OpenAPI)</span>
                <span className={`font-mono font-bold flex items-center space-x-1 ${
                  config.theme === 'light' ? 'text-sky-700' : 'text-sky-400'
                }`}>
                  <Clock className="w-3.5 h-3.5" />
                  <span>30s auto</span>
                </span>
              </div>

            </div>
          </div>

          {/* Embed Code Exporter */}
          <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-slate-700">
              <div className="flex items-center space-x-2">
                <Code className="w-4 h-4 text-sky-400" />
                <h3 className="font-bold text-slate-100 text-xs uppercase tracking-wide">
                  Código de Publicación Web (Opción B: Fondo Blanco)
                </h3>
              </div>

              {/* Code format tabs */}
              <div className="flex items-center space-x-1 bg-slate-900 p-1 rounded-lg border border-slate-700 text-xs">
                <button
                  onClick={() => setCodeType('iframe')}
                  className={`px-2.5 py-0.5 rounded font-semibold ${codeType === 'iframe' ? 'bg-sky-600 text-white' : 'text-slate-400'}`}
                >
                  HTML iFrame
                </button>
                <button
                  onClick={() => setCodeType('script')}
                  className={`px-2.5 py-0.5 rounded font-semibold ${codeType === 'script' ? 'bg-sky-600 text-white' : 'text-slate-400'}`}
                >
                  JS Script
                </button>
                <button
                  onClick={() => setCodeType('react')}
                  className={`px-2.5 py-0.5 rounded font-semibold ${codeType === 'react' ? 'bg-sky-600 text-white' : 'text-slate-400'}`}
                >
                  React Component
                </button>
              </div>
            </div>

            {/* Code Box */}
            <div className="relative">
              <pre className="p-4 rounded-xl bg-slate-950 text-sky-300 font-mono text-xs overflow-x-auto border border-slate-800 leading-relaxed">
                {codeType === 'iframe' && iframeCode}
                {codeType === 'script' && jsScriptCode}
                {codeType === 'react' && reactComponentCode}
              </pre>

              <button
                onClick={() => handleCopyCode(
                  codeType === 'iframe' ? iframeCode : (codeType === 'script' ? jsScriptCode : reactComponentCode),
                  codeType
                )}
                className="absolute top-3 right-3 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs shadow transition-all flex items-center space-x-1.5"
              >
                {copiedCode === codeType ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-300" />
                    <span>¡Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copiar Código</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[11px] text-slate-400">
              Pega este fragmento en tu sitio WordPress, Joomla, HTML5 o React. Se actualizará en tiempo real consumiendo directamente la API del Consorcio de Transportes de Asturias con fondo blanco y letras negras para máxima visibilidad.
            </p>

          </div>

        </div>

      </div>

    </div>
  );
};
