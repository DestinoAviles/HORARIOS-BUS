import React, { useState } from 'react';
import { CTA_API_SWAGGER_DOCS } from '../data/asturiasTransitData';
import { fetchStopItineraries } from '../services/ctaApiService';
import { Code2, Play, Copy, Check, Terminal, ExternalLink, RefreshCw } from 'lucide-react';

interface ApiPlaygroundProps {
  initialStopId?: string;
  initialMinutes?: number;
}

export const ApiPlayground: React.FC<ApiPlaygroundProps> = ({
  initialStopId = "33044001",
  initialMinutes = 30
}) => {
  const [selectedEndpointIdx, setSelectedEndpointIdx] = useState<number>(0);
  const [stopFisIdParam, setStopFisIdParam] = useState<string>(initialStopId);
  const [minutesParam, setMinutesParam] = useState<number>(initialMinutes);
  const [useForceMock, setUseForceMock] = useState<boolean>(false);

  const [loading, setLoading] = useState<boolean>(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [responseMeta, setResponseMeta] = useState<{ status: number; durationMs: number; isLive: boolean; url: string } | null>(null);
  const [copiedCurl, setCopiedCurl] = useState<boolean>(false);

  const activeDoc = CTA_API_SWAGGER_DOCS[selectedEndpointIdx] || CTA_API_SWAGGER_DOCS[0];

  const constructedUrl = `https://openapi.consorcioasturias.com/api/StopsFis/${encodeURIComponent(stopFisIdParam)}/${minutesParam}/itineraries`;

  const curlCommand = `curl -X 'GET' \\\n  '${constructedUrl}' \\\n  -H 'accept: application/json'`;

  const handleExecuteRequest = async () => {
    setLoading(true);
    setApiResponse(null);
    setResponseMeta(null);

    if (activeDoc.path.includes('StopsFis/{id}/{minutos}/itineraries')) {
      const startTime = performance.now();
      const res = await fetchStopItineraries(stopFisIdParam, minutesParam, useForceMock);
      const endTime = performance.now();

      setApiResponse(res.data);
      setResponseMeta({
        status: res.error ? 200 : 200,
        durationMs: Math.round(endTime - startTime),
        isLive: res.isLiveApi,
        url: res.urlCalled
      });
    } else {
      setTimeout(() => {
        setApiResponse(activeDoc.exampleResponse);
        setResponseMeta({
          status: 200,
          durationMs: 45,
          isLive: false,
          url: `https://openapi.consorcioasturias.com${activeDoc.path}`
        });
        setLoading(false);
      }, 300);
      return;
    }
    setLoading(false);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCurl(true);
    setTimeout(() => setCopiedCurl(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-sky-950 to-blue-950 rounded-2xl p-6 border border-sky-800/60 shadow-xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center space-x-2 mb-1">
              <span className="px-2.5 py-0.5 rounded bg-sky-500 text-slate-950 text-xs font-black uppercase">
                Consorcio Asturias OpenAPI
              </span>
              <a
                href="https://openapi.consorcioasturias.com/api/"
                target="_blank"
                rel="noreferrer"
                className="text-xs text-sky-300 hover:underline flex items-center space-x-1"
              >
                <span>https://openapi.consorcioasturias.com/api/</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">
              Explorador y Tester Interactivo de API
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl mt-1">
              Prueba los endpoints REST OpenAPI para consultas de paradas físicas (<span className="font-mono text-sky-300">StopsFis</span>), itinerarios de autobús y tiempos de paso.
            </p>
          </div>

          <button
            onClick={() => window.open('https://openapi.consorcioasturias.com/api/', '_blank')}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-sky-300 text-xs font-bold rounded-xl transition-colors flex items-center space-x-2 shrink-0"
          >
            <Code2 className="w-4 h-4" />
            <span>Swagger Oficial CTA</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Endpoint Selector List */}
        <div className="lg:col-span-4 bg-slate-800/90 rounded-2xl p-4 border border-slate-700 shadow-xl space-y-3">
          <div className="text-xs font-extrabold text-slate-400 uppercase tracking-wider px-2 pb-2 border-b border-slate-700">
            Endpoints Disponibles (CTA API)
          </div>

          <div className="space-y-2">
            {CTA_API_SWAGGER_DOCS.map((doc, idx) => {
              const isSelected = idx === selectedEndpointIdx;
              return (
                <button
                  key={doc.path}
                  onClick={() => setSelectedEndpointIdx(idx)}
                  className={`w-full text-left p-3 rounded-xl border transition-all space-y-1 ${
                    isSelected
                      ? 'bg-sky-950/80 border-sky-500 text-white shadow-md'
                      : 'bg-slate-900/60 border-slate-700/80 text-slate-300 hover:bg-slate-700/50'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className="px-2 py-0.5 rounded bg-sky-600 text-white font-mono text-[10px] font-bold">
                      {doc.method}
                    </span>
                    <span className="font-mono text-xs font-bold text-sky-300 truncate">
                      {doc.path}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 line-clamp-1">
                    {doc.summary}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Request Tester & Runner */}
        <div className="lg:col-span-8 space-y-6">
          
          <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-4">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-700">
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded bg-sky-600 text-white font-mono text-xs font-extrabold">
                  {activeDoc.method}
                </span>
                <span className="font-mono text-sm font-bold text-slate-100">
                  {activeDoc.path}
                </span>
              </div>

              <div className="flex items-center space-x-2">
                <label className="text-xs text-slate-400 flex items-center space-x-1 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={useForceMock}
                    onChange={(e) => setUseForceMock(e.target.checked)}
                    className="accent-sky-500 rounded"
                  />
                  <span>Forzar respuesta simulada</span>
                </label>
              </div>
            </div>

            <p className="text-xs text-slate-300">
              {activeDoc.description}
            </p>

            {/* Path Parameters Form */}
            {activeDoc.parameters.length > 0 && (
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-700/80 space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-sky-400">
                  Parámetros de la Consulta
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[11px] font-mono text-slate-300">
                      id (Código Parada Física CTA) *
                    </label>
                    <input
                      type="text"
                      value={stopFisIdParam}
                      onChange={(e) => setStopFisIdParam(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-sky-300 focus:outline-none focus:border-sky-500"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] font-mono text-slate-300">
                      minutos (Horizonte temporal) *
                    </label>
                    <input
                      type="number"
                      value={minutesParam}
                      onChange={(e) => setMinutesParam(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-mono text-sky-300 focus:outline-none focus:border-sky-500"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Execute Request Button */}
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono text-slate-400 truncate max-w-md">
                URL: <span className="text-sky-300">{constructedUrl}</span>
              </div>

              <button
                onClick={handleExecuteRequest}
                disabled={loading}
                className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-extrabold text-xs shadow-lg shadow-sky-600/30 transition-all flex items-center space-x-2 shrink-0"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Ejecutando...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white" />
                    <span>Probar Endpoint</span>
                  </>
                )}
              </button>
            </div>

          </div>

          {/* Response Box */}
          <div className="bg-slate-800/90 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-3">
            
            <div className="flex items-center justify-between pb-2 border-b border-slate-700">
              <div className="flex items-center space-x-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                <h3 className="font-bold text-slate-100 text-xs uppercase tracking-wide">
                  Respuesta HTTP (JSON Output)
                </h3>
              </div>

              {responseMeta && (
                <div className="flex items-center space-x-3 text-xs font-mono">
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                    Status: {responseMeta.status} OK
                  </span>
                  <span className="text-slate-400">{responseMeta.durationMs}ms</span>
                  <span className={responseMeta.isLive ? 'text-emerald-400 font-bold' : 'text-amber-400'}>
                    {responseMeta.isLive ? 'Live API' : 'Simulated'}
                  </span>
                </div>
              )}
            </div>

            {/* cURL Copy Box */}
            <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 font-mono text-xs text-slate-300 flex items-center justify-between">
              <div className="truncate pr-2 text-slate-400">
                {curlCommand.split('\n')[0]} ...
              </div>
              <button
                onClick={() => copyToClipboard(curlCommand)}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-sky-300 text-[11px] font-bold transition-colors flex items-center space-x-1 shrink-0"
              >
                {copiedCurl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedCurl ? '¡Copiado!' : 'Copiar cURL'}</span>
              </button>
            </div>

            {/* Raw JSON viewer */}
            <pre className="p-4 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs overflow-x-auto border border-slate-800 max-h-96 leading-relaxed">
              {apiResponse
                ? JSON.stringify(apiResponse, null, 2)
                : '// Haz clic en "Probar Endpoint" para ejecutar la consulta en tiempo real.'}
            </pre>

          </div>

        </div>

      </div>

    </div>
  );
};
