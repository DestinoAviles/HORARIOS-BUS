import React, { useState } from 'react';
import { ASTURIAS_LINES, ASTURIAS_STOPS } from '../data/asturiasTransitData';
import { Route, Clock, Building2, MapPin, Search, ChevronRight, Bus } from 'lucide-react';

interface LinesExplorerProps {
  onSelectStop: (stopId: string) => void;
}

export const LinesExplorer: React.FC<LinesExplorerProps> = ({ onSelectStop }) => {
  const [selectedLineId, setSelectedLineId] = useState<string>(ASTURIAS_LINES[0].id);
  const [searchTerm, setSearchTerm] = useState<string>('');

  const activeLine = ASTURIAS_LINES.find(l => l.id === selectedLineId) || ASTURIAS_LINES[0];

  const filteredLines = ASTURIAS_LINES.filter(l =>
    l.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.operator.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Find physical stops associated with this line
  const lineStops = ASTURIAS_STOPS.filter(s => s.linesServed.includes(activeLine.id));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* Left Column: Line List */}
      <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 shadow-xl space-y-4">
        <div className="flex items-center space-x-2 pb-2 border-b border-slate-700">
          <Route className="w-5 h-5 text-sky-400" />
          <h2 className="font-bold text-slate-100 text-sm tracking-wide uppercase">
            Líneas del Consorcio ({filteredLines.length})
          </h2>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filtrar por nombre o código..."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
          />
        </div>

        {/* List */}
        <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
          {filteredLines.map(line => {
            const isSelected = line.id === activeLine.id;
            return (
              <button
                key={line.id}
                onClick={() => setSelectedLineId(line.id)}
                className={`w-full text-left p-3.5 rounded-xl border transition-all flex items-center justify-between group ${
                  isSelected
                    ? 'bg-sky-950/80 border-sky-500 text-slate-100 shadow-md'
                    : 'bg-slate-900/60 border-slate-700/80 text-slate-300 hover:bg-slate-700/50'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div
                    className="w-9 h-9 rounded-lg font-black text-xs text-white flex items-center justify-center shadow"
                    style={{ backgroundColor: line.color }}
                  >
                    {line.code}
                  </div>
                  <div>
                    <div className="font-bold text-xs text-slate-100 group-hover:text-sky-300">
                      {line.name}
                    </div>
                    <div className="text-[11px] text-slate-400">
                      {line.operator}
                    </div>
                  </div>
                </div>
                <ChevronRight className={`w-4 h-4 ${isSelected ? 'text-sky-400' : 'text-slate-600'}`} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Right Column: Line Details & Stop Sequence */}
      <div className="lg:col-span-2 space-y-6">
        
        {/* Line Overview Card */}
        <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-700">
            <div className="flex items-center space-x-3">
              <div
                className="px-3.5 py-2 rounded-xl font-black text-lg text-white shadow-lg"
                style={{ backgroundColor: activeLine.color }}
              >
                {activeLine.code}
              </div>
              <div>
                <h1 className="text-xl font-extrabold text-white">
                  {activeLine.name}
                </h1>
                <p className="text-xs text-slate-400 flex items-center space-x-2">
                  <Building2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>Operador: {activeLine.operator} &bull; {activeLine.type}</span>
                </p>
              </div>
            </div>

            <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-700 text-xs text-slate-300 font-medium">
              {activeLine.zonesPassed.join(', ')}
            </span>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
            <div className="bg-slate-900 p-3 rounded-xl border border-slate-700/80">
              <Clock className="w-4 h-4 text-sky-400 mx-auto mb-1" />
              <div className="text-xs text-slate-400">Frecuencia</div>
              <div className="text-sm font-extrabold text-slate-100">Cada {activeLine.frequencyMinutes} min</div>
            </div>

            <div className="bg-slate-900 p-3 rounded-xl border border-slate-700/80">
              <Bus className="w-4 h-4 text-emerald-400 mx-auto mb-1" />
              <div className="text-xs text-slate-400">Tiempo estimado</div>
              <div className="text-sm font-extrabold text-slate-100">{activeLine.durationMinutes} minutos</div>
            </div>

            <div className="bg-slate-900 p-3 rounded-xl border border-slate-700/80">
              <MapPin className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
              <div className="text-xs text-slate-400">Paradas totales</div>
              <div className="text-sm font-extrabold text-slate-100">{activeLine.stopsCount} paradas</div>
            </div>

            <div className="bg-slate-900 p-3 rounded-xl border border-slate-700/80">
              <Route className="w-4 h-4 text-amber-400 mx-auto mb-1" />
              <div className="text-xs text-slate-400">Trayecto</div>
              <div className="text-xs font-bold text-slate-100 truncate">{activeLine.origin} → {activeLine.destination}</div>
            </div>
          </div>
        </div>

        {/* Physical Stops Sequence */}
        <div className="bg-slate-800/90 rounded-2xl p-6 border border-slate-700 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-extrabold text-slate-100 text-base flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-sky-400" />
              <span>Secuencia de Paradas Físicas Registradas</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              CTA StopsFis API
            </span>
          </div>

          <div className="space-y-3 relative before:absolute before:inset-0 before:left-3.5 before:w-0.5 before:bg-slate-700">
            {lineStops.length > 0 ? (
              lineStops.map((stop) => (
                <div key={stop.id} className="relative pl-8 flex items-center justify-between group">
                  <div className="absolute left-1.5 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-slate-900 border-2 border-sky-400 flex items-center justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-sky-400" />
                  </div>

                  <div className="space-y-0.5">
                    <div className="font-bold text-sm text-slate-100 group-hover:text-sky-300 transition-colors">
                      {stop.name}
                    </div>
                    <div className="text-xs text-slate-400">
                      ID: {stop.id} &bull; {stop.municipality} ({stop.zone})
                    </div>
                  </div>

                  <button
                    onClick={() => onSelectStop(stop.id)}
                    className="px-3 py-1.5 rounded-lg bg-sky-600/20 hover:bg-sky-600 text-sky-300 hover:text-white border border-sky-500/40 text-xs font-semibold transition-all"
                  >
                    Ver Salidas
                  </button>
                </div>
              ))
            ) : (
              <div className="p-4 text-slate-400 text-xs italic">
                Paradas interurbanas genéricas de la red regional CTA Asturias.
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
