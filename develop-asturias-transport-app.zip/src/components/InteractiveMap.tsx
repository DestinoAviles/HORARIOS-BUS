import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { PhysicalStop } from '../types/cta';
import { ASTURIAS_LINES } from '../data/asturiasTransitData';
import { Bus, Navigation, Eye, Compass } from 'lucide-react';

interface InteractiveMapProps {
  stops: PhysicalStop[];
  selectedStopId: string;
  onSelectStop: (stopId: string) => void;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  stops,
  selectedStopId,
  onSelectStop
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});
  const [selectedMunicipality, setSelectedMunicipality] = useState<string>('ALL');
  const [showRoutes, setShowRoutes] = useState<boolean>(true);
  const routePolylinesRef = useRef<L.Polyline[]>([]);

  const municipalities = Array.from(new Set(stops.map(s => s.municipality)));

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Center over Asturias (Oviedo / Gijón area)
      const map = L.map(mapContainerRef.current, {
        center: [43.4000, -5.8000],
        zoom: 10,
        zoomControl: true
      });

      // Dark theme tiles (OpenStreetMap with CARTO dark basemap)
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        maxZoom: 19
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Render Stop Markers
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear existing markers
    Object.values(markersRef.current).forEach(m => m.remove());
    markersRef.current = {};

    // Custom Icon generator
    const createCustomIcon = (isSelected: boolean) => {
      const color = isSelected ? '#0284c7' : '#0f172a';
      const border = isSelected ? '#38bdf8' : '#64748b';

      return L.divIcon({
        className: 'custom-bus-pin',
        html: `
          <div style="
            background-color: ${color};
            border: 2px solid ${border};
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            transform: scale(${isSelected ? 1.25 : 1});
            transition: all 0.2s ease;
          ">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${isSelected ? '#ffffff' : '#38bdf8'}" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <path d="M4 16c0 .88.39 1.67 1 2.22V20c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1h8v1c0 .55.45 1 1 1h1c.55 0 1-.45 1-1v-1.78c.61-.55 1-1.34 1-2.22V6c0-3.5-3.58-4-8-4s-8 .5-8 4v10z"/>
              <circle cx="7.5" cy="15.5" r="1.5"/>
              <circle cx="16.5" cy="15.5" r="1.5"/>
            </svg>
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
        popupAnchor: [0, -16]
      });
    };

    const filteredStops = selectedMunicipality === 'ALL'
      ? stops
      : stops.filter(s => s.municipality === selectedMunicipality);

    filteredStops.forEach(stop => {
      const isSelected = stop.id === selectedStopId;
      const marker = L.marker([stop.latitude, stop.longitude], {
        icon: createCustomIcon(isSelected)
      }).addTo(map);

      // Popup HTML content
      const popupContent = document.createElement('div');
      popupContent.className = 'p-3 text-slate-100 font-sans space-y-2';
      popupContent.innerHTML = `
        <div style="font-size: 10px; font-weight: 700; color: #38bdf8; text-transform: uppercase;">
          ID: ${stop.id} &bull; ${stop.zone}
        </div>
        <div style="font-weight: 800; font-size: 14px; color: #f8fafc; line-height: 1.2;">
          ${stop.name}
        </div>
        <div style="font-size: 11px; color: #94a3b8;">
          ${stop.municipality} ${stop.address ? '&bull; ' + stop.address : ''}
        </div>
        <button id="btn-stop-${stop.id}" style="
          width: 100%;
          margin-top: 8px;
          background-color: #0284c7;
          color: white;
          border: none;
          padding: 6px 12px;
          border-radius: 8px;
          font-weight: 700;
          font-size: 12px;
          cursor: pointer;
        ">
          🚌 Ver Tiempos en Real-Time
        </button>
      `;

      marker.bindPopup(popupContent);

      marker.on('click', () => {
        onSelectStop(stop.id);
      });

      // Add event listener to popup button after open
      marker.on('popupopen', () => {
        const btn = document.getElementById(`btn-stop-${stop.id}`);
        if (btn) {
          btn.onclick = () => {
            onSelectStop(stop.id);
            map.closePopup();
          };
        }
      });

      markersRef.current[stop.id] = marker;
    });

    // Pan to selected stop
    const activeStop = stops.find(s => s.id === selectedStopId);
    if (activeStop) {
      map.panTo([activeStop.latitude, activeStop.longitude], { animate: true });
    }

  }, [stops, selectedStopId, selectedMunicipality, onSelectStop]);

  // Route polylines
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    // Clear existing polylines
    routePolylinesRef.current.forEach(p => p.remove());
    routePolylinesRef.current = [];

    if (showRoutes) {
      ASTURIAS_LINES.forEach(line => {
        if (line.routeCoordinates && line.routeCoordinates.length > 1) {
          const polyline = L.polyline(line.routeCoordinates, {
            color: line.color,
            weight: 4,
            opacity: 0.75,
            dashArray: '8, 8'
          }).addTo(map);

          polyline.bindTooltip(`Línea ${line.code}: ${line.name}`, { sticky: true });
          routePolylinesRef.current.push(polyline);
        }
      });
    }
  }, [showRoutes]);

  const handleUserLocation = () => {
    if (!navigator.geolocation || !mapInstanceRef.current) return;

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        mapInstanceRef.current?.setView([latitude, longitude], 13);
        L.marker([latitude, longitude])
          .addTo(mapInstanceRef.current!)
          .bindPopup('Tu ubicación actual')
          .openPopup();
      },
      () => {
        alert('No se pudo obtener la ubicación GPS.');
      }
    );
  };

  return (
    <div className="space-y-4">
      {/* Map Control Bar */}
      <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        
        <div className="flex items-center space-x-3 w-full sm:w-auto">
          <label className="font-semibold text-slate-300 flex items-center space-x-1.5 shrink-0">
            <Compass className="w-4 h-4 text-sky-400" />
            <span>Filtrar por Municipio:</span>
          </label>
          <select
            value={selectedMunicipality}
            onChange={(e) => setSelectedMunicipality(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:border-sky-500 w-full sm:w-auto"
          >
            <option value="ALL">Todo el Principado de Asturias</option>
            {municipalities.map(m => (
              <option key={m} value={m}>{m}</option>
            ))}
          </select>
        </div>

        <div className="flex items-center space-x-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => setShowRoutes(!showRoutes)}
            className={`px-3 py-1.5 rounded-lg border font-semibold transition-all flex items-center space-x-1.5 ${
              showRoutes
                ? 'bg-sky-600 border-sky-500 text-white'
                : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-slate-200'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Ver Rutas de Autobús</span>
          </button>

          <button
            onClick={handleUserLocation}
            className="px-3 py-1.5 bg-slate-900 hover:bg-slate-700 border border-slate-700 text-sky-400 font-semibold rounded-lg transition-colors flex items-center space-x-1.5"
            title="Ubicarme en el mapa"
          >
            <Navigation className="w-3.5 h-3.5" />
            <span>Mi GPS</span>
          </button>
        </div>

      </div>

      {/* Leaflet Map Canvas */}
      <div className="relative h-[550px] rounded-2xl overflow-hidden border border-slate-700 shadow-2xl bg-slate-950">
        <div ref={mapContainerRef} className="w-full h-full" />

        {/* Floating Stop Badge Legend */}
        <div className="absolute bottom-4 left-4 z-[500] bg-slate-900/90 backdrop-blur-md p-3 rounded-xl border border-slate-700/80 text-xs shadow-xl hidden sm:block">
          <div className="font-bold text-slate-200 mb-1 flex items-center space-x-1">
            <Bus className="w-3.5 h-3.5 text-sky-400" />
            <span>Leyenda CTA Asturias</span>
          </div>
          <div className="space-y-1 text-[11px] text-slate-300">
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-sky-500 border border-sky-300 inline-block" />
              <span>Parada Seleccionada</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="w-3 h-3 rounded-full bg-slate-900 border border-slate-500 inline-block" />
              <span>Parada Física Registrada</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
