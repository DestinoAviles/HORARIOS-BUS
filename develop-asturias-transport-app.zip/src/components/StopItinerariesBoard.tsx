import React, { useState, useEffect, useCallback } from 'react';
import { PhysicalStop, DepartureItinerary } from '../types/cta';
import { fetchStopItineraries, ApiFetchResult } from '../services/ctaApiService';
import { ASTURIAS_STOPS } from '../data/asturiasTransitData';
import {
  Search,
  Clock,
  RefreshCw,
  Bookmark,
  Wifi,
  Accessibility,
  Building2,
  SlidersHorizontal,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  Zap,
  MapPin,
  Flame,
  Volume2
} from 'lucide-react';

interface StopItinerariesBoardProps {
  stops: PhysicalStop[];
  selectedStopId: string;
  setSelectedStopId: (id: string) => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
  useLiveApi: boolean;
  onOpenApiPlayground?: (stopId: string, minutes: number) => void;
  onOpenWidgetBuilder?: (stopId: string, minutes: number) => void;
  appTheme?: 'dark' | 'light';
}

export const StopItinerariesBoard: React.FC<StopItinerariesBoardProps> = ({
  stops,
  selectedStopId,
  setSelectedStopId,
  favorites,
  toggleFavorite,
  useLiveApi,
  onOpenApiPlayground,
  onOpenWidgetBuilder,
  appTheme = 'dark'
}) => {
  const isLight = appTheme === 'light';

  const [minutes, setMinutes] = useState<number>(30);
  const [itineraries, setItineraries] = useState<DepartureItinerary[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [apiMeta, setApiMeta] = useState<ApiFetchResult<DepartureItinerary[]> | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedOperator, setSelectedOperator] = useState<string>('ALL');
  const [autoRefreshSec, setAutoRefreshSec] = useState<number>(30);
  const [speakingItineraryId, setSpeakingItineraryId] = useState<string | null>(null);

  const currentStop = stops.find(s => s.id === selectedStopId) || stops[0] || ASTURIAS_STOPS[0];

  const loadItineraries = useCallback(async () => {
    setLoading(true);
    const result = await fetchStopItineraries(selectedStopId, minutes, !useLiveApi);
    setItineraries(result.data);
    setApiMeta(result);
    setLoading(false);
    setAutoRefreshSec(30);
  }, [selectedStopId, minutes, useLiveApi]);

  useEffect(() => {
    loadItineraries();
  }, [loadItineraries]);

  // Countdown auto-refresh
  useEffect(() => {
    const timer = setInterval(() => {
      setAutoRefreshSec((prev) => {
        if (prev <= 1) {
          loadItineraries();
          return 30;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [loadItineraries]);

  const filteredStops = stops.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.id.includes(searchTerm) ||
    s.municipality.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const operators = Array.from(new Set(itineraries.map(i => i.operator)));

  const displayItineraries = itineraries.filter(i => {
    if (selectedOperator !== 'ALL' && !i.operator.includes(selectedOperator)) {
      return false;
    }
    return true;
  });

  const isFavorite = favorites.includes(selectedStopId);

  // Text-To-Speech for accessibility / audio announcements
  const handleAudioAnnouncement = (itinerary: DepartureItinerary) => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const text = `Próximo autobús línea ${itinerary.lineCode} con destino ${itinerary.destination}, llegada estimada en ${itinerary.estimatedMinutes} minutos por la ${itinerary.platform || 'dársena asignada'}.`;
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-ES';
      utterance.rate = 0.95;
      setSpeakingItineraryId(itinerary.id);
      utterance.onend = () => setSpeakingItineraryId(null);
      utterance.onerror = () => setSpeakingItineraryId(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Controls & Stop Selector */}
      <div className={`rounded-2xl p-5 border shadow-xl space-y-4 transition-colors ${
        isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-slate-800/90 border-slate-700 text-slate-100'
      }`}>
        
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Main Stop Dropdown / Search */}
          <div className="flex-1 space-y-2">
            <label className={`text-xs font-extrabold uppercase tracking-wider flex items-center space-x-1.5 ${
              isLight ? 'text-sky-700' : 'text-sky-400'
            }`}>
              <MapPin className="w-3.5 h-3.5" />
              <span>Seleccionar Parada Física CTA (StopsFis)</span>
            </label>
            <div className="relative">
              <div className="flex items-center space-x-2">
                <div className="relative flex-1">
                  <select
                    value={selectedStopId}
                    onChange={(e) => setSelectedStopId(e.target.value)}
                    className={`w-full rounded-xl px-4 py-3 text-sm font-bold focus:ring-2 focus:ring-sky-500 outline-none appearance-none pr-10 border shadow-xs ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-950'
                        : 'bg-slate-900 border-slate-700 text-slate-100'
                    }`}
                  >
                    {stops.map(s => (
                      <option key={s.id} value={s.id}>
                        [{s.id}] {s.name} ({s.municipality})
                      </option>
                    ))}
                  </select>
                  <ChevronRight className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none rotate-90" />
                </div>

                {/* Bookmark favorite button */}
                <button
                  onClick={() => toggleFavorite(selectedStopId)}
                  className={`p-3 rounded-xl border transition-all flex items-center justify-center ${
                    isFavorite
                      ? 'bg-amber-500/20 border-amber-500/60 text-amber-500'
                      : isLight
                      ? 'bg-slate-100 border-slate-300 text-slate-600 hover:text-amber-500'
                      : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-amber-400'
                  }`}
                  title={isFavorite ? 'Quitar de favoritos' : 'Guardar en favoritos'}
                >
                  <Bookmark className={`w-5 h-5 ${isFavorite ? 'fill-amber-500' : ''}`} />
                </button>
              </div>
            </div>
          </div>

          {/* Minutes Lookahead Range Selector */}
          <div className="w-full lg:w-auto space-y-2">
            <label className={`text-xs font-extrabold uppercase tracking-wider flex items-center space-x-1.5 ${
              isLight ? 'text-sky-700' : 'text-sky-400'
            }`}>
              <Clock className="w-3.5 h-3.5" />
              <span>Ventana de Tiempo ({minutes} min)</span>
            </label>
            <div className={`flex items-center space-x-1 p-1 rounded-xl border ${
              isLight ? 'bg-slate-100 border-slate-300' : 'bg-slate-900 border-slate-700'
            }`}>
              {[5, 15, 30, 60, 120].map((m) => (
                <button
                  key={m}
                  onClick={() => setMinutes(m)}
                  className={`px-3 py-2 text-xs font-bold rounded-lg transition-all ${
                    minutes === m
                      ? 'bg-sky-600 text-white shadow-xs'
                      : isLight ? 'text-slate-700 hover:text-slate-950 hover:bg-slate-200' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Search Filter bar */}
        <div className={`pt-2 border-t flex flex-col sm:flex-row items-center justify-between gap-3 text-xs ${
          isLight ? 'border-slate-200' : 'border-slate-700/60'
        }`}>
          <div className="relative w-full sm:w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar parada por nombre o ID..."
              className={`w-full border rounded-lg pl-8 pr-3 py-1.5 font-medium focus:outline-none focus:border-sky-500 ${
                isLight
                  ? 'bg-slate-50 border-slate-300 text-slate-900 placeholder-slate-500'
                  : 'bg-slate-900/80 border-slate-700/80 text-slate-200 placeholder-slate-500'
              }`}
            />
          </div>

          <div className="flex items-center space-x-2 w-full sm:w-auto justify-between sm:justify-end">
            {/* Operator filter */}
            {operators.length > 1 && (
              <div className="flex items-center space-x-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={selectedOperator}
                  onChange={(e) => setSelectedOperator(e.target.value)}
                  className={`border rounded-lg px-2.5 py-1 font-semibold focus:outline-none ${
                    isLight ? 'bg-slate-50 border-slate-300 text-slate-900' : 'bg-slate-900 border-slate-700 text-slate-300'
                  }`}
                >
                  <option value="ALL">Todos los operadores</option>
                  {operators.map(op => (
                    <option key={op} value={op}>{op}</option>
                  ))}
                </select>
              </div>
            )}

            {/* Manual refresh button */}
            <button
              onClick={loadItineraries}
              disabled={loading}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-bold transition-colors ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300'
                  : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
              }`}
            >
              <RefreshCw className={`w-3.5 h-3.5 text-sky-600 ${loading ? 'animate-spin' : ''}`} />
              <span>Actualizar ({autoRefreshSec}s)</span>
            </button>
          </div>
        </div>

      </div>

      {/* API Endpoint Banner & Stop Header */}
      <div className={`rounded-2xl p-5 shadow-lg border relative overflow-hidden ${
        isLight
          ? 'bg-gradient-to-r from-sky-50 via-white to-blue-50 border-sky-300 text-slate-900'
          : 'bg-gradient-to-r from-sky-950/70 via-slate-900 to-cyan-950/70 border-sky-800/40 text-white'
      }`}>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative z-10">
          
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <span className={`px-2.5 py-0.5 rounded-md font-mono text-xs font-bold border ${
                isLight ? 'bg-sky-100 border-sky-300 text-sky-950' : 'bg-sky-900/80 border-sky-700/80 text-sky-300'
              }`}>
                ID: {currentStop.id}
              </span>
              <span className={`px-2.5 py-0.5 rounded-md text-xs font-bold ${
                isLight ? 'bg-slate-200 text-slate-800' : 'bg-slate-800 text-slate-300'
              }`}>
                {currentStop.zone}
              </span>
              <span className={`px-2.5 py-0.5 rounded-md text-xs font-bold flex items-center space-x-1 border ${
                isLight ? 'bg-emerald-100 border-emerald-300 text-emerald-900' : 'bg-emerald-950 border-emerald-800/60 text-emerald-300'
              }`}>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <span>En servicio</span>
              </span>
            </div>

            <h1 className={`text-xl sm:text-2xl font-black tracking-tight ${
              isLight ? 'text-slate-950' : 'text-white'
            }`}>
              {currentStop.name}
            </h1>
            <p className={`text-xs font-semibold flex items-center space-x-2 ${
              isLight ? 'text-slate-700' : 'text-slate-400'
            }`}>
              <span>{currentStop.address || currentStop.logicalStopName} &bull; {currentStop.municipality}</span>
            </p>
          </div>

          {/* Quick Actions: API Inspector & Publish Widget */}
          <div className="flex items-center space-x-2 w-full md:w-auto">
            {onOpenWidgetBuilder && (
              <button
                onClick={() => onOpenWidgetBuilder(currentStop.id, minutes)}
                className="flex-1 md:flex-none flex items-center justify-center space-x-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold shadow-md shadow-emerald-600/20 transition-all"
              >
                <Flame className="w-4 h-4 text-emerald-100" />
                <span>Publicar en mi Web (Opción B)</span>
              </button>
            )}

            {onOpenApiPlayground && (
              <button
                onClick={() => onOpenApiPlayground(currentStop.id, minutes)}
                className={`flex-1 md:flex-none flex items-center justify-center space-x-1.5 px-3.5 py-2 rounded-xl border text-xs font-bold transition-all ${
                  isLight
                    ? 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-sky-800'
                    : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-sky-400'
                }`}
              >
                <Zap className="w-4 h-4" />
                <span>Probar Endpoint API</span>
              </button>
            )}
          </div>

        </div>

        {/* Live URL endpoint call notice */}
        {apiMeta && (
          <div className={`mt-4 pt-3 border-t flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2 font-mono p-2.5 rounded-lg border ${
            isLight
              ? 'bg-slate-100/80 border-slate-200 text-slate-800'
              : 'bg-slate-950/40 border-slate-800/80 text-slate-400'
          }`}>
            <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar">
              <span className="font-bold text-sky-700">GET</span>
              <span className={`truncate font-semibold ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>{apiMeta.urlCalled}</span>
            </div>

            <div className="flex items-center space-x-3 shrink-0">
              <span className={apiMeta.isLiveApi ? 'text-emerald-700 font-bold' : 'text-amber-700 font-bold'}>
                {apiMeta.isLiveApi ? '● API En Vivo' : '● Simulación Real-Time'}
              </span>
              <span className="text-slate-400">|</span>
              <span className="font-bold">{apiMeta.responseTimeMs}ms</span>
            </div>
          </div>
        )}
      </div>

      {/* Main Departures Board Table / Cards with Clear High-Contrast Light Mode Typography */}
      <div className={`rounded-2xl border shadow-2xl overflow-hidden transition-colors ${
        isLight ? 'bg-white border-slate-300' : 'bg-slate-800/90 border-slate-700'
      }`}>
        
        {/* Board Header */}
        <div className={`px-5 py-4 border-b flex items-center justify-between ${
          isLight ? 'bg-slate-100 border-slate-200' : 'bg-slate-900/80 border-slate-700/80'
        }`}>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-live-dot" />
            <h2 className={`font-extrabold text-sm tracking-wide uppercase ${
              isLight ? 'text-slate-950' : 'text-slate-100'
            }`}>
              Próximas Salidas e Itinerarios ({displayItineraries.length})
            </h2>
          </div>
          <span className={`text-xs font-bold ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
            Horizonte: próximos {minutes} minutos
          </span>
        </div>

        {/* Loading state */}
        {loading ? (
          <div className="p-12 text-center space-y-3">
            <RefreshCw className="w-8 h-8 text-sky-600 animate-spin mx-auto" />
            <p className={`text-sm font-bold ${isLight ? 'text-slate-800' : 'text-slate-300'}`}>
              Consultando OpenAPI de Consorcio Asturias...
            </p>
            <p className="text-xs text-slate-500 font-mono">
              /api/StopsFis/{selectedStopId}/{minutes}/itineraries
            </p>
          </div>
        ) : displayItineraries.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
            <p className={`text-base font-extrabold ${isLight ? 'text-slate-900' : 'text-slate-200'}`}>
              No se encontraron viajes programados en los próximos {minutes} minutos
            </p>
            <p className={`text-xs max-w-md mx-auto ${isLight ? 'text-slate-600' : 'text-slate-400'}`}>
              Prueba a ampliar el rango de tiempo (ej. 60 min o 120 min) o selecciona otra parada del consorcio.
            </p>
            <button
              onClick={() => setMinutes(60)}
              className="mt-2 px-4 py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-extrabold transition-colors"
            >
              Ampliar a 60 minutos
            </button>
          </div>
        ) : (
          <div className={`divide-y ${isLight ? 'divide-slate-200' : 'divide-slate-700/60'}`}>
            {displayItineraries.map((item) => {
              const isBoarding = item.status === 'BOARDING' || item.estimatedMinutes <= 1;
              const isDelayed = item.status === 'DELAYED' || item.delayMinutes > 2;

              return (
                <div
                  key={item.id}
                  className={`p-4 sm:p-5 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4 group ${
                    isLight ? 'hover:bg-slate-50' : 'hover:bg-slate-700/40'
                  }`}
                >
                  {/* Left Column: Line Badge & Destination */}
                  <div className="flex items-start space-x-4">
                    
                    {/* Line Badge */}
                    <div className="shrink-0 space-y-1 text-center">
                      <div className="px-3.5 py-1.5 rounded-xl font-black text-sm sm:text-base text-white bg-gradient-to-r from-sky-600 to-blue-700 shadow-md border border-sky-400/30">
                        {item.lineCode}
                      </div>
                      <span className={`text-[10px] uppercase tracking-wider block font-mono font-bold ${
                        isLight ? 'text-slate-600' : 'text-slate-400'
                      }`}>
                        {item.platform || 'Dársena'}
                      </span>
                    </div>

                    {/* Route Details */}
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className={`font-black text-base sm:text-lg transition-colors ${
                          isLight ? 'text-slate-950 group-hover:text-sky-700' : 'text-slate-100 group-hover:text-sky-300'
                        }`}>
                          {item.destination}
                        </span>
                      </div>

                      <p className={`text-xs font-bold ${isLight ? 'text-slate-700' : 'text-slate-300'}`}>
                        {item.lineName}
                      </p>

                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        {/* Operator Tag */}
                        <span className={`inline-flex items-center space-x-1 text-[11px] font-bold px-2 py-0.5 rounded border ${
                          isLight
                            ? 'bg-slate-100 border-slate-300 text-slate-800'
                            : 'bg-slate-900 border-slate-700 text-slate-300'
                        }`}>
                          <Building2 className="w-3 h-3 text-sky-600" />
                          <span>{item.operator}</span>
                        </span>

                        {/* Vehicle Type */}
                        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                          isLight ? 'bg-slate-100 text-slate-700' : 'bg-slate-900/60 text-slate-400'
                        }`}>
                          {item.vehicleType}
                        </span>

                        {/* Accessibility Icons */}
                        {item.hasAccessibility && (
                          <span className="p-0.5 text-sky-600" title="Accesible PMR">
                            <Accessibility className="w-3.5 h-3.5" />
                          </span>
                        )}
                        {item.hasWifi && (
                          <span className="p-0.5 text-cyan-600" title="Wifi gratuito">
                            <Wifi className="w-3.5 h-3.5" />
                          </span>
                        )}

                        {/* Occupancy Indicator */}
                        <span className={`text-[10px] font-extrabold px-1.5 py-0.2 rounded uppercase ${
                          item.occupancy === 'BAJA'
                            ? (isLight ? 'bg-emerald-100 text-emerald-950 border border-emerald-300' : 'bg-emerald-950 text-emerald-300 border border-emerald-800')
                            : item.occupancy === 'MEDIA'
                            ? (isLight ? 'bg-amber-100 text-amber-950 border border-amber-300' : 'bg-amber-950 text-amber-300 border border-amber-800')
                            : (isLight ? 'bg-rose-100 text-rose-950 border border-rose-300' : 'bg-rose-950 text-rose-300 border border-rose-800')
                        }`}>
                          Ocupación {item.occupancy}
                        </span>
                      </div>
                    </div>

                  </div>

                  {/* Right Column: Minutes Countdown & Status */}
                  <div className={`flex items-center justify-between md:justify-end space-x-4 pt-3 md:pt-0 border-t md:border-t-0 ${
                    isLight ? 'border-slate-200' : 'border-slate-700/50'
                  }`}>
                    
                    {/* Audio Announcement button */}
                    <button
                      onClick={() => handleAudioAnnouncement(item)}
                      className={`p-2 rounded-xl border transition-colors ${
                        speakingItineraryId === item.id
                          ? 'bg-sky-600 text-white border-sky-400 animate-pulse'
                          : isLight
                          ? 'bg-slate-100 text-slate-700 hover:text-sky-700 border-slate-300'
                          : 'bg-slate-900 text-slate-400 hover:text-sky-400 border-slate-700'
                      }`}
                      title="Escuchar anuncio de voz"
                    >
                      <Volume2 className="w-4 h-4" />
                    </button>

                    {/* Schedule times */}
                    <div className="text-right space-y-0.5">
                      <div className={`text-xs flex items-center justify-end space-x-1 font-bold ${
                        isLight ? 'text-slate-600' : 'text-slate-400'
                      }`}>
                        <span>Prog:</span>
                        <span className="font-mono">{item.scheduledTime}</span>
                      </div>
                      
                      {isDelayed ? (
                        <div className="text-xs font-bold text-amber-600 flex items-center space-x-1">
                          <AlertTriangle className="w-3 h-3" />
                          <span>+{item.delayMinutes} min restr.</span>
                        </div>
                      ) : (
                        <div className="text-xs font-bold text-emerald-600 flex items-center space-x-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>En hora</span>
                        </div>
                      )}
                    </div>

                    {/* Countdown Time Pill */}
                    <div className="shrink-0 text-center">
                      {isBoarding ? (
                        <div className="px-3.5 py-2 rounded-xl bg-emerald-500 text-slate-950 font-black text-xs uppercase tracking-wider animate-bounce shadow-lg shadow-emerald-500/20">
                          En Parada
                        </div>
                      ) : (
                        <div className={`px-4 py-2 rounded-xl border font-extrabold text-lg sm:text-xl shadow-inner flex flex-col items-center ${
                          isLight
                            ? 'bg-sky-50 border-sky-300 text-sky-950'
                            : 'bg-slate-900 border-sky-500/40 text-sky-400'
                        }`}>
                          <span className="leading-none">{item.estimatedMinutes}</span>
                          <span className={`text-[10px] uppercase font-bold tracking-wider ${
                            isLight ? 'text-slate-600' : 'text-slate-400'
                          }`}>min</span>
                        </div>
                      )}
                    </div>

                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>

      {/* Quick Search List of Stops */}
      {searchTerm && (
        <div className={`rounded-2xl p-4 border transition-colors ${
          isLight ? 'bg-white border-slate-300' : 'bg-slate-800/90 border-slate-700'
        }`}>
          <h3 className={`text-xs font-bold uppercase tracking-wider mb-3 ${
            isLight ? 'text-slate-700' : 'text-slate-400'
          }`}>
            Resultados de búsqueda de paradas ({filteredStops.length})
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {filteredStops.map(s => (
              <button
                key={s.id}
                onClick={() => {
                  setSelectedStopId(s.id);
                  setSearchTerm('');
                }}
                className={`text-left p-3 rounded-xl border transition-colors flex items-center justify-between group ${
                  isLight
                    ? 'bg-slate-50 hover:bg-sky-50 border-slate-200 hover:border-sky-300'
                    : 'bg-slate-900/60 hover:bg-sky-950/60 border-slate-700/80 hover:border-sky-500/50'
                }`}
              >
                <div>
                  <div className={`font-bold text-xs group-hover:text-sky-600 ${
                    isLight ? 'text-slate-900' : 'text-slate-200'
                  }`}>
                    {s.name}
                  </div>
                  <div className={`text-[11px] font-mono ${
                    isLight ? 'text-slate-600' : 'text-slate-400'
                  }`}>
                    ID: {s.id} &bull; {s.municipality}
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-sky-600" />
              </button>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
