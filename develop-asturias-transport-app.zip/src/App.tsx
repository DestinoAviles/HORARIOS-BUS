import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { StopItinerariesBoard } from './components/StopItinerariesBoard';
import { InteractiveMap } from './components/InteractiveMap';
import { LinesExplorer } from './components/LinesExplorer';
import { TripPlanner } from './components/TripPlanner';
import { FareCalculator } from './components/FareCalculator';
import { WebWidgetBuilder } from './components/WebWidgetBuilder';
import { ApiPlayground } from './components/ApiPlayground';
import { FavoritesManager } from './components/FavoritesManager';
import { Footer } from './components/Footer';
import { ASTURIAS_STOPS } from './data/asturiasTransitData';
import { fetchPhysicalStops, fetchStopItineraries } from './services/ctaApiService';
import { PhysicalStop, DepartureItinerary } from './types/cta';
import { Bus, RefreshCw, Clock } from 'lucide-react';

export function App() {
  const [stops, setStops] = useState<PhysicalStop[]>(ASTURIAS_STOPS);
  const [selectedStopId, setSelectedStopId] = useState<string>("33044001"); // Oviedo Estación
  const [activeTab, setActiveTab] = useState<string>("board");
  
  const [useLiveApi, setUseLiveApi] = useState<boolean>(true);
  const [isLiveConnected, setIsLiveConnected] = useState<boolean>(true);
  const [lastResponseMs, setLastResponseMs] = useState<number>(45);

  // App Theme Switcher: 'dark' or 'light' (Fondo Blanco - Letras Negras)
  const [appTheme, setAppTheme] = useState<'dark' | 'light'>('dark');

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('cta_favorites');
      return saved ? JSON.parse(saved) : ["33044001", "33024001"];
    } catch {
      return ["33044001", "33024001"];
    }
  });

  const [isFavoritesOpen, setIsFavoritesOpen] = useState<boolean>(false);

  // Widget Embed mode detection
  const urlParams = typeof window !== 'undefined' ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const isWidgetMode = urlParams.get('widget') === 'true';
  const widgetStopId = urlParams.get('stopId') || selectedStopId;
  const widgetMinutes = Number(urlParams.get('minutos') || 30);
  const widgetTheme = urlParams.get('theme') || 'light';

  const [widgetItineraries, setWidgetItineraries] = useState<DepartureItinerary[]>([]);
  const [widgetLoading, setWidgetLoading] = useState<boolean>(false);

  // Save favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('cta_favorites', JSON.stringify(favorites));
    } catch (e) {
      console.error(e);
    }
  }, [favorites]);

  const toggleFavorite = (stopId: string) => {
    setFavorites(prev =>
      prev.includes(stopId) ? prev.filter(id => id !== stopId) : [...prev, stopId]
    );
  };

  // Initial load of physical stops
  useEffect(() => {
    fetchPhysicalStops(!useLiveApi).then(res => {
      if (res.data && res.data.length > 0) {
        setStops(res.data);
      }
      setIsLiveConnected(res.isLiveApi);
      setLastResponseMs(res.responseTimeMs);
    });
  }, [useLiveApi]);

  // Handle Widget Standalone Render mode
  useEffect(() => {
    if (isWidgetMode) {
      setWidgetLoading(true);
      fetchStopItineraries(widgetStopId, widgetMinutes, false).then(res => {
        setWidgetItineraries(res.data);
        setWidgetLoading(false);
      });

      const timer = setInterval(() => {
        fetchStopItineraries(widgetStopId, widgetMinutes, false).then(res => {
          setWidgetItineraries(res.data);
        });
      }, 30000);

      return () => clearInterval(timer);
    }
  }, [isWidgetMode, widgetStopId, widgetMinutes]);

  // Standalone Embed Widget View with Light / Dark theme support
  if (isWidgetMode) {
    const currentWidgetStop = stops.find(s => s.id === widgetStopId) || ASTURIAS_STOPS[0];
    const isLightWidget = widgetTheme === 'light';

    return (
      <div className={`min-h-screen p-3 font-sans ${isLightWidget ? 'bg-white text-slate-900' : 'bg-slate-950 text-slate-100'}`}>
        <div className={`rounded-xl overflow-hidden shadow-2xl border ${
          isLightWidget ? 'bg-white border-slate-300' : 'bg-slate-900 border-slate-700'
        }`}>
          {/* Widget Header */}
          <div className={`p-3.5 flex items-center justify-between ${
            isLightWidget ? 'bg-slate-100 border-b border-slate-200 text-slate-950' : 'bg-gradient-to-r from-sky-900 to-blue-900 text-white'
          }`}>
            <div>
              <div className={`text-[10px] font-mono uppercase tracking-wider font-bold ${
                isLightWidget ? 'text-sky-700' : 'text-sky-200'
              }`}>
                [{currentWidgetStop.id}] {currentWidgetStop.municipality} &bull; CTA ASTURIAS
              </div>
              <div className="font-extrabold text-sm sm:text-base tracking-tight">
                {currentWidgetStop.name}
              </div>
            </div>
            <Bus className={`w-5 h-5 ${isLightWidget ? 'text-sky-700' : 'text-sky-300'}`} />
          </div>

          {/* Widget Departures List */}
          <div className={`p-3 space-y-2 ${
            isLightWidget ? 'divide-y divide-slate-200 bg-white' : 'divide-y divide-slate-800 bg-slate-900'
          }`}>
            {widgetLoading ? (
              <div className={`py-8 text-center space-y-2 text-xs font-semibold ${
                isLightWidget ? 'text-slate-600' : 'text-slate-400'
              }`}>
                <RefreshCw className="w-5 h-5 text-sky-600 animate-spin mx-auto" />
                <span>Cargando salidas en tiempo real...</span>
              </div>
            ) : widgetItineraries.length === 0 ? (
              <div className={`py-6 text-center text-xs font-semibold ${
                isLightWidget ? 'text-slate-600' : 'text-slate-400'
              }`}>
                No hay salidas próximas
              </div>
            ) : (
              widgetItineraries.slice(0, 5).map((it) => (
                <div key={it.id} className="pt-2.5 first:pt-0 flex items-center justify-between text-xs">
                  <div className="flex items-center space-x-2.5">
                    <span className="px-2.5 py-1 rounded-md bg-sky-600 text-white font-black text-xs shadow-xs">
                      {it.lineCode}
                    </span>
                    <div>
                      <div className={`font-black text-xs sm:text-sm ${
                        isLightWidget ? 'text-slate-950' : 'text-slate-100'
                      }`}>
                        {it.destination}
                      </div>
                      <div className={`text-[10px] font-semibold ${
                        isLightWidget ? 'text-slate-600' : 'text-slate-400'
                      }`}>
                        {it.operator} {it.platform ? `• ${it.platform}` : ''}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className={`text-[11px] font-mono font-bold ${
                      isLightWidget ? 'text-slate-600' : 'text-slate-400'
                    }`}>{it.scheduledTime}</span>
                    <div className={`px-2.5 py-1 rounded-lg font-black text-xs ${
                      isLightWidget
                        ? 'bg-sky-100 border border-sky-300 text-sky-950'
                        : 'bg-sky-950 border border-sky-500/50 text-sky-300'
                    }`}>
                      {it.estimatedMinutes} min
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className={`p-2.5 text-[10px] font-bold border-t flex justify-between px-3 ${
            isLightWidget ? 'bg-slate-100 border-slate-200 text-slate-700' : 'bg-slate-950 border-slate-800 text-slate-400'
          }`}>
            <span>CTA Asturias OpenAPI</span>
            <span className={`flex items-center space-x-1 font-mono ${
              isLightWidget ? 'text-sky-700' : 'text-sky-400'
            }`}>
              <Clock className="w-3 h-3" />
              <span>Auto-refresh 30s</span>
            </span>
          </div>
        </div>
      </div>
    );
  }

  // Full Web Application View
  return (
    <div className={`min-h-screen flex flex-col selection:bg-sky-500 selection:text-white transition-colors duration-200 ${
      appTheme === 'light' ? 'bg-slate-100 text-slate-900' : 'bg-slate-900 text-slate-100'
    }`}>
      {/* Navigation with Theme Switcher */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        favoritesCount={favorites.length}
        openFavoritesModal={() => setIsFavoritesOpen(true)}
        useLiveApi={useLiveApi}
        setUseLiveApi={setUseLiveApi}
        isLiveConnected={isLiveConnected}
        lastResponseMs={lastResponseMs}
        appTheme={appTheme}
        setAppTheme={setAppTheme}
      />

      {/* Main App Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'board' && (
          <StopItinerariesBoard
            stops={stops}
            selectedStopId={selectedStopId}
            setSelectedStopId={setSelectedStopId}
            favorites={favorites}
            toggleFavorite={toggleFavorite}
            useLiveApi={useLiveApi}
            onOpenApiPlayground={(id) => {
              setSelectedStopId(id);
              setActiveTab('api');
            }}
            onOpenWidgetBuilder={(id) => {
              setSelectedStopId(id);
              setActiveTab('widget');
            }}
            appTheme={appTheme}
          />
        )}

        {activeTab === 'map' && (
          <InteractiveMap
            stops={stops}
            selectedStopId={selectedStopId}
            onSelectStop={(id) => {
              setSelectedStopId(id);
              setActiveTab('board');
            }}
          />
        )}

        {activeTab === 'lines' && (
          <LinesExplorer
            onSelectStop={(id) => {
              setSelectedStopId(id);
              setActiveTab('board');
            }}
          />
        )}

        {activeTab === 'planner' && (
          <TripPlanner
            stops={stops}
            onSelectStop={(id) => {
              setSelectedStopId(id);
              setActiveTab('board');
            }}
          />
        )}

        {activeTab === 'fares' && (
          <FareCalculator />
        )}

        {activeTab === 'widget' && (
          <WebWidgetBuilder
            stops={stops}
            initialStopId={selectedStopId}
          />
        )}

        {activeTab === 'api' && (
          <ApiPlayground
            initialStopId={selectedStopId}
          />
        )}
      </main>

      {/* Favorites Drawer Modal */}
      <FavoritesManager
        isOpen={isFavoritesOpen}
        onClose={() => setIsFavoritesOpen(false)}
        favorites={favorites}
        stops={stops}
        onSelectStop={(id) => {
          setSelectedStopId(id);
          setActiveTab('board');
        }}
        toggleFavorite={toggleFavorite}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}

export default App;
