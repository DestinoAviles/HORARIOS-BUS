import { PhysicalStop, TransitLine, DepartureItinerary } from '../types/cta';

export const ASTURIAS_STOPS: PhysicalStop[] = [
  {
    id: "33044001",
    name: "Estación de Autobuses de Oviedo (Dársenas Principales)",
    logicalStopName: "Estación de Autobuses de Oviedo",
    municipality: "Oviedo",
    zone: "Zona Central (A)",
    latitude: 43.3688,
    longitude: -5.8481,
    address: "Calle Pepe Cosmen 1, 33001 Oviedo",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-GIJ-E", "OVI-AVI-E", "OVI-AER", "OVI-MIE", "TUA-L1"]
  },
  {
    id: "33044002",
    name: "HUCA - Hospital Universitario Central de Asturias (Acceso Principal)",
    logicalStopName: "HUCA - Oviedo",
    municipality: "Oviedo",
    zone: "Zona Central (A)",
    latitude: 43.3765,
    longitude: -5.8282,
    address: "Av. del Hospital Universitario s/n, Oviedo",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["TUA-L1", "OVI-GIJ-E", "OVI-SIERO"]
  },
  {
    id: "33044003",
    name: "Campus El Milán - Calle Milanés",
    logicalStopName: "Universidad de Oviedo - El Milán",
    municipality: "Oviedo",
    zone: "Zona Central (A)",
    latitude: 43.3695,
    longitude: -5.8398,
    address: "Calle Amparo Pedregal, Oviedo",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["TUA-L1", "TUA-L2"]
  },
  {
    id: "33024001",
    name: "Gijón - Plaza del Humedal / Estación de Autobuses",
    logicalStopName: "Gijón Central - Humedal",
    municipality: "Gijón",
    zone: "Zona Central (B)",
    latitude: 43.5392,
    longitude: -5.6663,
    address: "Plaza de Europa / Llanes, 33206 Gijón",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-GIJ-E", "GIJ-AVI-E", "EMT-L10", "EMT-L1"]
  },
  {
    id: "33024002",
    name: "Campus Universitario de Viesques (Gijón)",
    logicalStopName: "Universidad de Oviedo - Campus Viesques",
    municipality: "Gijón",
    zone: "Zona Central (B)",
    latitude: 43.5228,
    longitude: -5.6322,
    address: "Avenida de Justo Ureña, Gijón",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["EMT-L10", "OVI-GIJ-E"]
  },
  {
    id: "33004001",
    name: "Estación de Autobuses de Avilés",
    logicalStopName: "Estación Intermodal de Avilés",
    municipality: "Avilés",
    zone: "Zona Central (C)",
    latitude: 43.5583,
    longitude: -5.9238,
    address: "Av. de los Telégrafos 1, 33401 Avilés",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-AVI-E", "GIJ-AVI-E", "AVI-AER"]
  },
  {
    id: "33000001",
    name: "Aeropuerto de Asturias (Terminal Salidas)",
    logicalStopName: "Aeropuerto de Asturias (OVD)",
    municipality: "Castrillón",
    zone: "Zona Aeropuerto",
    latitude: 43.5636,
    longitude: -6.0346,
    address: "Santiago del Monte, Castrillón",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-AER", "GIJ-AER", "AVI-AER"]
  },
  {
    id: "33037001",
    name: "Mieres - Estación de Autobuses (Calle Vega)",
    logicalStopName: "Estación de Autobuses de Mieres",
    municipality: "Mieres",
    zone: "Zona Caudal (D)",
    latitude: 43.2505,
    longitude: -5.7761,
    address: "Calle Vega 18, Mieres",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-MIE", "MIE-LAN"]
  },
  {
    id: "33031001",
    name: "Langreo - La Felguera Estación",
    logicalStopName: "La Felguera Intermodal",
    municipality: "Langreo",
    zone: "Zona Nalón (E)",
    latitude: 43.3088,
    longitude: -5.6908,
    address: "Calle Pedro Duro, Langreo",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-LAN", "MIE-LAN"]
  },
  {
    id: "33066001",
    name: "Pola de Siero - Estación de Autobuses",
    logicalStopName: "Pola de Siero",
    municipality: "Siero",
    zone: "Zona Siero (F)",
    latitude: 43.3912,
    longitude: -5.6603,
    address: "Calle de la Isla, Pola de Siero",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-SIERO", "GIJ-SIERO"]
  },
  {
    id: "33076001",
    name: "Villaviciosa - Estación de Autobuses",
    logicalStopName: "Estación Villaviciosa",
    municipality: "Villaviciosa",
    zone: "Zona Oriente (G)",
    latitude: 43.4815,
    longitude: -5.4332,
    address: "Calle Victor García de la Concha",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["GIJ-VIL", "OVI-VIL"]
  },
  {
    id: "33036001",
    name: "Llanes - Estación de Autobuses",
    logicalStopName: "Estación de Autobuses de Llanes",
    municipality: "Llanes",
    zone: "Zona Costa Oriente (H)",
    latitude: 43.4211,
    longitude: -4.7554,
    address: "Calle Nemesio Sobrino 1, Llanes",
    hasShelter: true,
    isAccessible: true,
    linesServed: ["OVI-LLA", "GIJ-LLA"]
  }
];

export const ASTURIAS_LINES: TransitLine[] = [
  {
    id: "OVI-GIJ-E",
    code: "OVI-GIJ",
    name: "Oviedo - Gijón Express (Autopista Y)",
    operator: "ALSA (Consorcio CTA)",
    color: "#0284c7", // Sky blue
    type: "Línea Directa",
    origin: "Oviedo Estación Autobuses",
    destination: "Gijón Plaza Humedal",
    durationMinutes: 28,
    frequencyMinutes: 15,
    stopsCount: 6,
    zonesPassed: ["Zona Central (A)", "Zona Central (B)"],
    routeCoordinates: [
      [43.3688, -5.8481],
      [43.3765, -5.8282],
      [43.4350, -5.7800],
      [43.5000, -5.7200],
      [43.5392, -5.6663]
    ]
  },
  {
    id: "OVI-AVI-E",
    code: "OVI-AVI",
    name: "Oviedo - Avilés por Autopista",
    operator: "ALSA (Consorcio CTA)",
    color: "#059669", // Emerald
    type: "Línea Directa",
    origin: "Oviedo Estación Autobuses",
    destination: "Avilés Estación",
    durationMinutes: 25,
    frequencyMinutes: 20,
    stopsCount: 5,
    zonesPassed: ["Zona Central (A)", "Zona Central (C)"],
    routeCoordinates: [
      [43.3688, -5.8481],
      [43.4100, -5.8800],
      [43.4900, -5.9100],
      [43.5583, -5.9238]
    ]
  },
  {
    id: "OVI-AER",
    code: "OVI-AER",
    name: "Oviedo - Aeropuerto de Asturias",
    operator: "ALSA (Consorcio CTA)",
    color: "#d97706", // Amber
    type: "Interurbano",
    origin: "Oviedo Estación Autobuses",
    destination: "Aeropuerto de Asturias",
    durationMinutes: 45,
    frequencyMinutes: 30,
    stopsCount: 8,
    zonesPassed: ["Zona Central (A)", "Zona Central (C)", "Zona Aeropuerto"],
    routeCoordinates: [
      [43.3688, -5.8481],
      [43.5583, -5.9238],
      [43.5636, -6.0346]
    ]
  },
  {
    id: "GIJ-AVI-E",
    code: "GIJ-AVI",
    name: "Gijón - Avilés Express",
    operator: "Automóviles Luarca / CTA",
    color: "#7c3aed", // Violet
    type: "Línea Directa",
    origin: "Gijón Plaza Humedal",
    destination: "Avilés Estación",
    durationMinutes: 22,
    frequencyMinutes: 20,
    stopsCount: 4,
    zonesPassed: ["Zona Central (B)", "Zona Central (C)"],
    routeCoordinates: [
      [43.5392, -5.6663],
      [43.5450, -5.7800],
      [43.5583, -5.9238]
    ]
  },
  {
    id: "TUA-L1",
    code: "TUA L-1",
    name: "TUA L1: HUCA - San Claudio",
    operator: "TUA (Transportes Unidos de Asturias)",
    color: "#e11d48", // Rose
    type: "Urbano Oviedo (TUA)",
    origin: "HUCA Hospital",
    destination: "San Claudio",
    durationMinutes: 35,
    frequencyMinutes: 10,
    stopsCount: 24,
    zonesPassed: ["Zona Central (A)"],
    routeCoordinates: [
      [43.3765, -5.8282],
      [43.3695, -5.8398],
      [43.3688, -5.8481],
      [43.3610, -5.8820]
    ]
  },
  {
    id: "EMT-L10",
    code: "EMTUSA L-10",
    name: "EMTUSA L10: Pumarín - Somió / Viesques",
    operator: "EMTUSA (Gijón)",
    color: "#2563eb", // Blue
    type: "Urbano Gijón (EMTUSA)",
    origin: "Pumarín",
    destination: "Campus Viesques / Somió",
    durationMinutes: 30,
    frequencyMinutes: 12,
    stopsCount: 22,
    zonesPassed: ["Zona Central (B)"],
    routeCoordinates: [
      [43.5200, -5.6780],
      [43.5392, -5.6663],
      [43.5228, -5.6322]
    ]
  },
  {
    id: "OVI-MIE",
    code: "OVI-MIE",
    name: "Oviedo - Mieres por Autopista A-66",
    operator: "ALSA (Consorcio CTA)",
    color: "#0891b2", // Cyan
    type: "Interurbano",
    origin: "Oviedo Estación Autobuses",
    destination: "Mieres Estación",
    durationMinutes: 20,
    frequencyMinutes: 30,
    stopsCount: 6,
    zonesPassed: ["Zona Central (A)", "Zona Caudal (D)"],
    routeCoordinates: [
      [43.3688, -5.8481],
      [43.2505, -5.7761]
    ]
  }
];

export function generateMockItineraries(stopId: string, lookaheadMinutes: number = 60): DepartureItinerary[] {
  const stop = ASTURIAS_STOPS.find(s => s.id === stopId) || ASTURIAS_STOPS[0];
  const now = new Date();

  // Find lines serving this stop
  const lines = ASTURIAS_LINES.filter(l => stop.linesServed.includes(l.id) || stop.linesServed.length === 0);
  const activeLines = lines.length > 0 ? lines : ASTURIAS_LINES.slice(0, 3);

  const itineraries: DepartureItinerary[] = [];

  activeLines.forEach((line, lineIdx) => {
    // Generate 2 to 4 departures for each line within the lookahead window
    const intervals = [3, 11, 24, 38, 52, 75, 95, 115].filter(m => m <= lookaheadMinutes + 10);

    intervals.forEach((minOffset, i) => {
      const depTime = new Date(now.getTime() + (minOffset + lineIdx * 2) * 60000);
      const hours = depTime.getHours().toString().padStart(2, '0');
      const mins = depTime.getMinutes().toString().padStart(2, '0');
      const timeStr = `${hours}:${mins}`;

      const delay = Math.random() > 0.6 ? Math.floor(Math.random() * 4) + 1 : 0;
      const totalMinutes = minOffset + lineIdx * 2;

      let status: DepartureItinerary['status'] = 'REALTIME';
      if (totalMinutes <= 1) {
        status = 'BOARDING';
      } else if (delay > 2) {
        status = 'DELAYED';
      } else if (Math.random() > 0.8) {
        status = 'SCHEDULED';
      }

      // Determine platform
      const platformNum = (lineIdx + i) % 12 + 1;

      itineraries.push({
        id: `it-${stopId}-${line.id}-${i}-${depTime.getTime()}`,
        stopFisId: stopId,
        lineId: line.id,
        lineCode: line.code,
        lineName: line.name,
        origin: line.origin,
        destination: line.destination === stop.logicalStopName ? line.origin : line.destination,
        scheduledTime: timeStr,
        estimatedTime: timeStr,
        estimatedMinutes: Math.max(0, totalMinutes),
        status,
        delayMinutes: delay,
        platform: `Dársena ${platformNum}`,
        operator: line.operator,
        vehicleType: i % 2 === 0 ? "Autobús Adaptado 100% Eléctrico" : "Autobús Interurbano Low Floor",
        hasAccessibility: true,
        hasWifi: true,
        occupancy: totalMinutes < 10 ? 'ALTA' : (totalMinutes < 25 ? 'MEDIA' : 'BAJA'),
        nextStops: [line.destination, "Campus Universitario", "Estación Central"]
      });
    });
  });

  // Sort by estimated minutes ascending
  return itineraries.sort((a, b) => a.estimatedMinutes - b.estimatedMinutes);
}

export const CTA_FARES_TABLE = [
  { zones: 1, singleTicket: 1.55, ctaMonedero: 0.90, ctaConecta: 0.00, desc: "Viajes dentro del mismo municipio (Ej. Todo Oviedo o Todo Gijón)" },
  { zones: 2, singleTicket: 2.10, ctaMonedero: 1.35, ctaConecta: 0.00, desc: "Entre municipios colindantes (Ej. Oviedo - Lugones, Gijón - Candás)" },
  { zones: 3, singleTicket: 3.25, ctaMonedero: 2.10, ctaConecta: 0.00, desc: "Tres zonas de distancia (Ej. Oviedo - Avilés, Gijón - Pola de Siero)" },
  { zones: 4, singleTicket: 4.40, ctaMonedero: 2.85, ctaConecta: 0.00, desc: "Cuatro zonas (Ej. Oviedo - Mieres, Gijón - Villaviciosa)" },
  { zones: 5, singleTicket: 5.80, ctaMonedero: 3.75, ctaConecta: 0.00, desc: "Cinco zonas (Ej. Oviedo - Cangas de Onís, Gijón - Luarca)" },
  { zones: 6, singleTicket: 7.20, ctaMonedero: 4.60, ctaConecta: 0.00, desc: "Seis zonas o más en red regional CTA" }
];

export const CTA_API_SWAGGER_DOCS = [
  {
    method: 'GET' as const,
    path: '/api/StopsFis/{id}/{minutos}/itineraries',
    summary: 'Obtiene las salidas e itinerarios en tiempo real de una parada física',
    description: 'Devuelve la lista de servicios/autobuses que pasarán por la parada física con identificador {id} durante los próximos {minutos} minutos.',
    parameters: [
      { name: 'id', in: 'path' as const, required: true, type: 'string', description: 'Código de Parada Física CTA (ej. 33044001 para Oviedo Estación)', example: '33044001' },
      { name: 'minutos', in: 'path' as const, required: true, type: 'integer', description: 'Ventana de tiempo en minutos hacia el futuro (ej. 15, 30, 60, 120)', example: '30' }
    ],
    exampleResponse: {
      "stopFisId": "33044001",
      "stopName": "Estación de Autobuses de Oviedo (Dársenas Principales)",
      "requestedMinutes": 30,
      "timestamp": new Date().toISOString(),
      "itineraries": [
        {
          "id": "it-33044001-OVI-GIJ-E-1",
          "lineCode": "OVI-GIJ",
          "lineName": "Oviedo - Gijón Express (Autopista Y)",
          "destination": "Gijón Plaza Humedal",
          "scheduledTime": "14:30",
          "estimatedTime": "14:32",
          "estimatedMinutes": 5,
          "status": "REALTIME",
          "delayMinutes": 2,
          "platform": "Dársena 4",
          "operator": "ALSA (Consorcio CTA)",
          "vehicleType": "Autobús Adaptado 100% Eléctrico",
          "hasAccessibility": true,
          "occupancy": "MEDIA"
        }
      ]
    }
  },
  {
    method: 'GET' as const,
    path: '/api/StopsFis',
    summary: 'Lista completa de paradas físicas del Consorcio CTA',
    description: 'Devuelve todas las paradas físicas registradas con sus coordenadas geográficas, municipio y líneas asociadas.',
    parameters: [
      { name: 'municipality', in: 'query' as const, required: false, type: 'string', description: 'Filtrar por municipio de Asturias (ej. Oviedo, Gijón)', example: 'Oviedo' }
    ],
    exampleResponse: ASTURIAS_STOPS.slice(0, 2)
  },
  {
    method: 'GET' as const,
    path: '/api/Lines',
    summary: 'Lista de líneas de transporte del Consorcio de Asturias',
    description: 'Obtiene las líneas urbanas e interurbanas gestionadas por el CTA (ALSA, TUA, EMTUSA, etc.).',
    parameters: [
      { name: 'operator', in: 'query' as const, required: false, type: 'string', description: 'Filtrar por operador (ej. ALSA, TUA, EMTUSA)', example: 'ALSA' }
    ],
    exampleResponse: ASTURIAS_LINES.slice(0, 2)
  },
  {
    method: 'GET' as const,
    path: '/api/FareZones',
    summary: 'Tarifas y zonificación CTA Conecta',
    description: 'Información sobre zonificación y preciario del billete CTA Monedero y Tarjeta CONECTA.',
    parameters: [],
    exampleResponse: CTA_FARES_TABLE
  }
];
