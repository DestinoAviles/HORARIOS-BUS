export interface PhysicalStop {
  id: string; // e.g. "33044001"
  name: string; // "Estación de Autobuses de Oviedo - Dársenas"
  logicalStopName: string; // "Estación de Autobuses de Oviedo"
  municipality: string; // "Oviedo"
  zone: string; // "Zona A"
  latitude: number;
  longitude: number;
  address?: string;
  hasShelter: boolean;
  isAccessible: boolean;
  linesServed: string[];
}

export interface DepartureItinerary {
  id: string;
  stopFisId: string;
  lineId: string;
  lineCode: string;
  lineName: string;
  origin: string;
  destination: string;
  scheduledTime: string; // "14:30"
  estimatedTime: string; // "14:32"
  estimatedMinutes: number; // 5
  status: 'REALTIME' | 'SCHEDULED' | 'DELAYED' | 'BOARDING' | 'DEPARTED';
  delayMinutes: number; // e.g. 2 or 0
  platform?: string; // "Dársena 12"
  operator: string; // "ALSA", "TUA", "EMTUSA", etc.
  vehicleType: string; // "Autobús Adaptado 100% Eléctrico"
  hasAccessibility: boolean;
  hasWifi: boolean;
  occupancy: 'BAJA' | 'MEDIA' | 'ALTA';
  nextStops?: string[];
}

export interface TransitLine {
  id: string;
  code: string;
  name: string;
  operator: string;
  color: string;
  type: 'Interurbano' | 'Urbano Oviedo (TUA)' | 'Urbano Gijón (EMTUSA)' | 'Larga Distancia' | 'Línea Directa';
  origin: string;
  destination: string;
  durationMinutes: number;
  frequencyMinutes: number;
  stopsCount: number;
  zonesPassed: string[];
  routeCoordinates: [number, number][]; // lat, lng
}

export interface FareCalculation {
  zonesCount: number;
  originZone: string;
  destinationZone: string;
  singleTicketPrice: number;
  ctaMonederoPrice: number;
  ctaConectaPrice: number;
  savingsPercentage: number;
  monthlyCapReached: boolean;
}

export interface WidgetConfig {
  stopId: string;
  minutes: number;
  theme: 'light' | 'sky' | 'emerald' | 'violet' | 'amber' | 'slate';
  mode: 'board' | 'compact' | 'kiosk' | 'badge';
  showHeader: boolean;
  showOperator: boolean;
  showPlatform: boolean;
  autoRefresh: number; // seconds
  customTitle: string;
  width: string;
  height: string;
}

export interface ApiEndpointSpec {
  method: 'GET' | 'POST';
  path: string;
  summary: string;
  description: string;
  parameters: {
    name: string;
    in: 'path' | 'query';
    required: boolean;
    type: string;
    description: string;
    example: string;
  }[];
  exampleResponse: any;
}
