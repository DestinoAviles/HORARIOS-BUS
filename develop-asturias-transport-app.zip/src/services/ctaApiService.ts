import { PhysicalStop, DepartureItinerary } from '../types/cta';
import { ASTURIAS_STOPS, generateMockItineraries } from '../data/asturiasTransitData';

const BASE_URL = 'https://openapi.consorcioasturias.com/api';

export interface ApiFetchResult<T> {
  data: T;
  isLiveApi: boolean;
  error?: string;
  urlCalled: string;
  responseTimeMs: number;
}

/**
 * Fetch stop itineraries from `https://openapi.consorcioasturias.com/api/StopsFis/{id}/{minutos}/itineraries`
 * With CORS fallback to realistic mock data.
 */
export async function fetchStopItineraries(
  stopFisId: string,
  minutos: number = 30,
  forceMock: boolean = false
): Promise<ApiFetchResult<DepartureItinerary[]>> {
  const url = `${BASE_URL}/StopsFis/${encodeURIComponent(stopFisId)}/${minutos}/itineraries`;
  const startTime = performance.now();

  if (forceMock) {
    const mockData = generateMockItineraries(stopFisId, minutos);
    return {
      data: mockData,
      isLiveApi: false,
      urlCalled: url,
      responseTimeMs: Math.round(performance.now() - startTime)
    };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json'
      },
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const liveJson = await response.json();
      const mappedData: DepartureItinerary[] = Array.isArray(liveJson)
        ? liveJson.map((item, idx) => mapRawItineraryToModel(item, stopFisId, idx))
        : (liveJson.itineraries ? liveJson.itineraries.map((item: any, idx: number) => mapRawItineraryToModel(item, stopFisId, idx)) : []);

      return {
        data: mappedData.length > 0 ? mappedData : generateMockItineraries(stopFisId, minutos),
        isLiveApi: true,
        urlCalled: url,
        responseTimeMs: Math.round(performance.now() - startTime)
      };
    } else {
      throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
    }
  } catch (err: any) {
    // Graceful fallback to rich mock simulation
    const mockData = generateMockItineraries(stopFisId, minutos);
    return {
      data: mockData,
      isLiveApi: false,
      error: `No se pudo conectar directamente con la API en vivo (${err.message || 'CORS o red'}). Mostrando datos de simulación en tiempo real.`,
      urlCalled: url,
      responseTimeMs: Math.round(performance.now() - startTime)
    };
  }
}

/**
 * Fetch all physical stops from CTA API
 */
export async function fetchPhysicalStops(forceMock: boolean = false): Promise<ApiFetchResult<PhysicalStop[]>> {
  const url = `${BASE_URL}/StopsFis`;
  const startTime = performance.now();

  if (forceMock) {
    return {
      data: ASTURIAS_STOPS,
      isLiveApi: false,
      urlCalled: url,
      responseTimeMs: Math.round(performance.now() - startTime)
    };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);

    const response = await fetch(url, {
      headers: { 'Accept': 'application/json' },
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (response.ok) {
      const json = await response.json();
      if (Array.isArray(json) && json.length > 0) {
        const mappedStops: PhysicalStop[] = json.map((s: any) => ({
          id: String(s.id || s.codigo || s.idStopFis),
          name: s.nombre || s.descripcion || s.name || `Parada ${s.id}`,
          logicalStopName: s.denominacion || s.municipio || "Asturias CTA",
          municipality: s.municipio || "Oviedo",
          zone: s.zona || "Zona A",
          latitude: Number(s.latitud || s.lat || 43.3688),
          longitude: Number(s.longitud || s.lon || -5.8481),
          address: s.direccion || s.calle || "",
          hasShelter: Boolean(s.marquesina ?? true),
          isAccessible: Boolean(s.accesible ?? true),
          linesServed: Array.isArray(s.lineas) ? s.lineas : ["OVI-GIJ-E"]
        }));

        return {
          data: mappedStops,
          isLiveApi: true,
          urlCalled: url,
          responseTimeMs: Math.round(performance.now() - startTime)
        };
      }
    }
    throw new Error("Formato de respuesta no esperado");
  } catch (err: any) {
    return {
      data: ASTURIAS_STOPS,
      isLiveApi: false,
      error: `Fallback local: ${err.message}`,
      urlCalled: url,
      responseTimeMs: Math.round(performance.now() - startTime)
    };
  }
}

function mapRawItineraryToModel(raw: any, stopFisId: string, idx: number): DepartureItinerary {
  const lineCode = raw.linea || raw.lineCode || raw.codigoLinea || "CTA";
  const lineName = raw.nombreLinea || raw.lineName || raw.destino || "Servicio CTA";
  const mins = typeof raw.minutos === 'number' ? raw.minutos : (raw.estimatedMinutes ?? (idx * 6 + 2));

  return {
    id: raw.id || `live-${stopFisId}-${idx}-${Date.now()}`,
    stopFisId,
    lineId: lineCode,
    lineCode: lineCode,
    lineName: lineName,
    origin: raw.origen || "Origen CTA",
    destination: raw.destino || raw.destination || "Gijón / Oviedo",
    scheduledTime: raw.horaProgramada || raw.scheduledTime || "14:30",
    estimatedTime: raw.horaEstimada || raw.estimatedTime || "14:32",
    estimatedMinutes: mins,
    status: mins <= 1 ? 'BOARDING' : (raw.retraso > 2 ? 'DELAYED' : 'REALTIME'),
    delayMinutes: raw.retraso || 0,
    platform: raw.darsena || raw.platform || `Dársena ${idx + 1}`,
    operator: raw.operador || raw.company || "ALSA / CTA",
    vehicleType: raw.tipoVehiculo || "Autobús Adaptado CTA",
    hasAccessibility: true,
    hasWifi: true,
    occupancy: 'MEDIA'
  };
}
